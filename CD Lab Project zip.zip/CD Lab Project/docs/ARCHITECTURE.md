# System Architecture

## High-Level Design

The system follows a 4-layer architecture:

1. **Frontend Layer**: Streamlit web UI
2. **NLP/Parsing Layer**: Intent extraction
3. **Code Generation Layer**: LLM integration
4. **Security Audit Layer**: Vulnerability detection + agent loop

## Module Dependencies

```
frontend.py
    └─→ agent_orchestrator.py
            └─→ agent.py
                    ├─→ compiler.py
                    └─→ auditor_basic.py
                            ├─→ ast_analyzer.py
                            └─→ dataflow_analyzer.py
```

## Data Flow

See deliverables/week04/ARCHITECTURE.md for detailed diagrams.

## Technology Stack

- **Frontend**: Streamlit
- **LLM**: OpenAI API + LangChain
- **Analysis**: Python AST, regex
- **Testing**: pytest
- **Visualization**: matplotlib, plotly
