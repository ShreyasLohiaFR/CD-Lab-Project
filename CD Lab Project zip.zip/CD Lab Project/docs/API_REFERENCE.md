# API Reference

## Core Classes

### CodeCompiler

Main code generation class.

```python
from src.compiler import CodeCompiler

compiler = CodeCompiler(model_name="gpt-4-turbo-preview")
code = compiler.generate_code("Create a login function")
intent = compiler.extract_intent("Build a secure API endpoint")
```

**Methods:**
- `generate_code(user_input: str) -> str`: Generate secure code
- `extract_intent(user_input: str) -> Dict[str, Any]`: Extract programming intent
- `regenerate_code(user_input: str, feedback: str) -> str`: Regenerate with feedback

### BasicAuditor

Vulnerability detection class.

```python
from src.auditor_basic import BasicAuditor

auditor = BasicAuditor()
vulnerabilities = auditor.audit(code)
is_secure, vulns = auditor.is_secure(code, max_vulnerabilities=0)
```

**Methods:**
- `audit(code: str) -> List[Dict[str, Any]]`: Audit code for vulnerabilities
- `is_secure(code: str, max_vulnerabilities: int) -> Tuple[bool, List]`: Check if code is secure

### SecurityAgent

Agentic AI agent for autonomous fixing.

```python
from src.agent import SecurityAgent

agent = SecurityAgent()
result = agent.execute_agent_loop("Create login", max_iterations=3)
```

**Methods:**
- `execute_agent_loop(user_input: str, max_iterations: int) -> Dict[str, Any]`: Execute agent loop

### InputValidator

Input validation and sanitization.

```python
from src.input_validator import InputValidator

validator = InputValidator()
is_valid, error = validator.validate_user_input(user_input)
sanitized = validator.sanitize_input(user_input)
```

### RateLimiter

Rate limiting for API protection.

```python
from src.rate_limiter import RateLimiter

limiter = RateLimiter(max_requests_per_minute=10)
allowed, reason = limiter.is_allowed("user_id")
stats = limiter.get_stats("user_id")
```

### CodeFormatter

Code formatting and quality enhancement.

```python
from src.code_formatter import CodeFormatter

formatter = CodeFormatter()
formatted = formatter.format_code(code)
analysis = formatter.enhance_code_quality(code)
suggestions = formatter.suggest_improvements(code)
```

## Configuration

Use environment variables or Config class:

```python
from src.config import Config

# Check configuration
status = Config.validate()
summary = Config.get_config_summary()
```

## Error Handling

All modules include comprehensive error handling:

```python
try:
    result = compiler.generate_code(input)
except ValueError as e:
    # Handle validation errors
except Exception as e:
    # Handle other errors
```
