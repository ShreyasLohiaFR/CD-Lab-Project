# Import ChatOpenAI from langchain-community
from langchain_community.chat_models import ChatOpenAI
from langchain.schema import HumanMessage

# Initialize the chat model
chat = ChatOpenAI(model_name="gpt-3.5-turbo", temperature=0.7)

# Ask the model something
response = chat.predict("Say hello in a friendly way.")

# Print the response
print("ChatGPT says:", response)
