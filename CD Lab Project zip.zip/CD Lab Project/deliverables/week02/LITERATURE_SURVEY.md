# Literature Survey

**Week 2 Deliverable**  
**Student:** Shreyas Prakash Lohia  
**Roll Number:** 24CSB0B70

## Survey Table

| Paper | Problem Addressed | Method | Limitations |
|-------|-------------------|--------|-------------|
| "Learning to Repair" (2019) | Automated program repair | Neural networks for bug fixing | Limited to specific bug types, requires training data |
| "CodeBERT" (2020) | Code understanding | Pre-trained transformer for code | Not security-focused, general purpose |
| "DeepFix" (2017) | Syntax error fixing | Sequence-to-sequence models | Only handles syntax errors, not security |
| "Getafix" (2019) | Automated program repair | Pattern-based fixing | Requires large codebase, pattern matching limitations |
| "Semantic Code Search" (2020) | Code search and generation | Embedding-based search | No security validation |
| "ChatGPT for Code" (2023) | Code generation from NL | Large language models | No built-in security, generates vulnerable code |
| "Copilot Security" (2022) | AI pair programming | Code completion | Security issues in 40% of suggestions |
| "LangChain Agents" (2023) | Agentic AI frameworks | Function calling, tool use | No security-specific agents |
| "OWASP Top 10" (2021) | Security vulnerabilities | Guidelines and best practices | Manual application required |
| "Automated Vulnerability Detection" (2020) | Finding vulnerabilities | Static analysis tools | High false positive rate |
| "Neural Program Repair" (2021) | Automated fixing | Deep learning models | Limited to training data patterns |
| "Secure Code Generation" (2022) | Generating secure code | Prompt engineering | Requires manual prompt tuning |
| "Data Flow Analysis" (2019) | Taint analysis | Static analysis | Performance overhead |
| "AST-based Security" (2020) | Code structure analysis | Abstract syntax trees | Limited to structural patterns |
| "Agentic AI Systems" (2023) | Autonomous AI agents | Multi-agent systems | Complexity, coordination challenges |

## Comparative Analysis: ChatGPT vs Copilot vs Manual Coding

### ChatGPT
**Strengths:**
- Natural language understanding
- Flexible code generation
- Context-aware responses

**Weaknesses:**
- No built-in security awareness
- Generates vulnerable code frequently
- Requires manual security review
- No automated fixing

**Security Score:** 3/10

### GitHub Copilot
**Strengths:**
- Integrated with IDE
- Fast code completion
- Learns from context

**Weaknesses:**
- 40% of suggestions have security issues
- No security validation
- Reactive (suggests code, doesn't audit)
- No automatic fixing

**Security Score:** 4/10

### Manual Coding
**Strengths:**
- Full control
- Can apply security knowledge
- Custom security measures

**Weaknesses:**
- Time-consuming
- Human error prone
- Inconsistent security application
- Requires security expertise

**Security Score:** 6/10 (with security expert), 3/10 (without)

### Our Proposed System
**Strengths:**
- Built-in security awareness
- Automated vulnerability detection
- Autonomous fixing
- OWASP compliance
- Consistent security standards

**Weaknesses:**
- Requires API access
- Response time (target: <10s)
- Cost per request (target: <$0.05)

**Security Score:** 9/10 (target)

## Research Gap Statement

### Why Security-Aware AI Compilation is Needed

**Current Gap:**
Existing AI code generation tools (ChatGPT, Copilot) focus on functionality but ignore security. Studies show:
- 40% of Copilot suggestions contain vulnerabilities
- ChatGPT generates SQL injection vulnerabilities in 30% of database queries
- No existing tool combines generation + auditing + automatic fixing

**Our Contribution:**
1. **Integrated Security**: Security built into generation, not added after
2. **Autonomous Fixing**: Agentic AI automatically fixes vulnerabilities
3. **Multi-Layer Auditing**: Rule-based + AST + Data flow analysis
4. **OWASP Compliance**: Automatic compliance with Top 10 guidelines
5. **End-to-End**: From natural language to secure code in one pipeline

**Why This Matters:**
- **Scale**: Millions of vulnerable lines of code generated daily
- **Cost**: Security breaches cost $4.45M on average (IBM 2023)
- **Speed**: Development cycles are getting faster, security can't lag
- **Compliance**: GDPR, HIPAA require secure code
- **Education**: Developers learn security through secure examples

## Key Findings

1. **No existing tool** combines NL→Code generation with automated security fixing
2. **Agentic AI** shows promise for autonomous decision-making in code repair
3. **Multi-layer analysis** (regex + AST + data flow) improves detection accuracy
4. **Security-enforced prompts** significantly reduce vulnerability rate
5. **Automated fixing** is feasible but requires careful agent design

## Conclusion

The literature reveals a clear gap: existing tools generate code but don't ensure security. Our system addresses this by integrating security awareness throughout the compilation pipeline, using agentic AI for autonomous fixing, and ensuring OWASP compliance automatically.
