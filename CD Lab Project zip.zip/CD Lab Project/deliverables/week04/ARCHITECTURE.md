z# System Architecture Document

**Week 4 Deliverable**

## High-Level System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    FRONTEND LAYER                             │
│                  (Streamlit Web UI)                           │
│  • Text input for natural language                            │
│  • Code output display                                        │
│  • Security report visualization                              │
│  • Download functionality                                     │
└────────────────────┬──────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│                  NLP/PARSING LAYER                            │
│              (Intent Extraction)                              │
│  • Natural language parsing                                   │
│  • Intent extraction                                          │
│  • Requirement analysis                                       │
└────────────────────┬──────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│              CODE GENERATION LAYER                            │
│            (LLM Integration)                                  │
│  • OpenAI API integration                                     │
│  • LangChain framework                                        │
│  • Security-enforced prompts                                  │
│  • Code generation                                            │
└────────────────────┬──────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│              SECURITY AUDIT LAYER                             │
│         (Vulnerability Detection)                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │
│  │ Rule-Based  │  │ AST Analyzer │  │ Data Flow    │       │
│  │ Auditor     │  │              │  │ Analyzer     │       │
│  └──────────────┘  └──────────────┘  └──────────────┘       │
└────────────────────┬──────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│            AGENTIC AI LAYER                                   │
│         (Autonomous Decision & Fixing)                        │
│  • LangChain Agents                                           │
│  • Function calling                                           │
│  • Autonomous decision loop                                   │
│  • Automatic vulnerability fixing                             │
└─────────────────────────────────────────────────────────────┘
```

## Module Interaction Diagram

```
User Input
    │
    ├─→ Frontend (Streamlit)
    │       │
    │       └─→ Orchestrator
    │               │
    │               ├─→ Compiler
    │               │       │
    │               │       ├─→ Intent Extraction
    │               │       └─→ Code Generation (LLM)
    │               │
    │               ├─→ Auditor
    │               │       │
    │               │       ├─→ Rule-Based Detection
    │               │       ├─→ AST Analysis
    │               │       └─→ Data Flow Analysis
    │               │
    │               ├─→ Agent
    │               │       │
    │               │       ├─→ Decision Making
    │               │       └─→ Code Fixing
    │               │
    │               └─→ Output (Secure Code + Report)
```

## Technology Stack Justification

### Frontend: Streamlit
- **Why**: Rapid development, Python-native, built-in components
- **Alternatives Considered**: Flask, Django, React
- **Decision**: Streamlit chosen for speed and simplicity

### LLM: OpenAI API + LangChain
- **Why**: State-of-the-art models, function calling support, agent framework
- **Alternatives**: Anthropic Claude, Google Gemini
- **Decision**: OpenAI for best code generation, LangChain for agent support

### Code Analysis: Python AST + Regex
- **Why**: Native Python support, fast pattern matching
- **Alternatives**: SonarQube, Bandit
- **Decision**: Custom solution for integration and control

### Testing: pytest
- **Why**: Python standard, excellent coverage tools
- **Decision**: Industry standard for Python testing

## Deployment Architecture

```
┌─────────────────┐
│   User Browser  │
└────────┬────────┘
         │ HTTPS
         ▼
┌─────────────────┐
│  Streamlit App  │
│  (Local/Cloud)  │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Python Backend │
│  (src modules)  │
└────────┬────────┘
         │ API
         ▼
┌─────────────────┐
│  OpenAI API     │
└─────────────────┘
```

## Data Flow Diagram

```
Natural Language Input
    │
    ├─→ Parse & Extract Intent
    │       │
    │       └─→ Structured Intent (JSON)
    │               │
    │               └─→ Generate Code (LLM)
    │                       │
    │                       └─→ Python Code
    │                               │
    │                               ├─→ Rule-Based Audit
    │                               ├─→ AST Analysis
    │                               └─→ Data Flow Analysis
    │                                       │
    │                                       └─→ Vulnerability Report
    │                                               │
    │                                               └─→ Agent Decision
    │                                                       │
    │                                                       ├─→ ACCEPT
    │                                                       │       │
    │                                                       │       └─→ Final Code
    │                                                       │
    │                                                       └─→ FIX
    │                                                               │
    │                                                               └─→ Fixed Code → Re-audit
```
