# Weekly Code Progression Plan (Weeks 1–14)

Use this as your show-and-tell guide. It maps the execution plan to code progress. By Week 14 the full system is complete (current `src/`). For earlier weeks, demo only the listed pieces and explain what’s planned next.

---
## Quick Index
- Week 1: Problem framing, no code
- Week 2: Research, no code
- Week 3: Requirements, no code
- Week 4: Architecture, stub entry point
- Week 5: Prompts & I/O spec, compiler skeleton
- Week 6: Frontend MVP (Streamlit), validation stubs
- Week 7: Core logic (compiler + basic auditor)
- Week 8: AST & data flow analyzers
- Week 9: Agentic loop (agent + orchestrator)
- Week 10: Optimizer + security enforcer
- Week 11: Test suite build-out
- Week 12: Evaluation docs & metrics hooks
- Week 13: Explainability + visualizations
- Week 14: Final polish (current full code)

---
## What to show each week (code + talking points)

### Week 1 — Problem understanding
- **Code:** None expected. Focus on docs.
- **Show:** `deliverables/week01/PROBLEM_DEFINITION.md`, `COMPILER_PHASES_DIAGRAM.md`.
- **Say:** “We’re planning a 4-phase compiler (parse → generate → audit → agentic fix).”

### Week 2 — Literature survey
- **Code:** None expected. Focus on research.
- **Show:** `deliverables/week02/LITERATURE_SURVEY.md`.
- **Say:** “Existing tools lack built-in security; no auto-fixing. Our gap: secure, agentic compiler.”

### Week 3 — Requirements & threats
- **Code:** None expected. Focus on SRS/threat model.
- **Show:** `deliverables/week03/SRS.md`.
- **Say:** “15 FRs, 8 NFRs, 5 threats; OWASP compliance and 10+ vuln types are requirements.”

### Week 4 — Architecture & design
- **Code:** Minimal stub if needed: `main.py` printing “compiler coming soon”.
- **Show:** `deliverables/week04/ARCHITECTURE.md`.
- **Say:** “4-layer architecture: UI → NLP → Generation → Security Audit/Agent.”

### Week 5 — Language/model/interface design
- **Code focus:** Prompts, I/O spec, compiler skeleton.
- **Files to show:**
  - `src/prompts.py` (prompt templates, vuln taxonomy)
  - `deliverables/week05/INPUT_OUTPUT_SPEC.md`
  - `main.py` simple CLI placeholder
- **Demo:** Optional: run `python main.py --input "hello"` returning a placeholder string.

### Week 6 — Frontend / parsing / validation
- **Code focus:** Streamlit UI MVP, basic input validation, error handling scaffolds.
- **Files to show:**
  - `src/frontend.py` (basic text box + button + output area)
  - `src/input_validator.py` (added later; mention as planned if not coded yet)
- **Demo:** `streamlit run src/frontend.py` shows UI; button returns a placeholder response.

### Week 7 — Core logic implementation
- **Code focus:** Code generation + basic auditor.
- **Files to show:**
  - `src/compiler.py` (LLM integration skeleton; safe fallbacks if no key)
  - `src/auditor_basic.py` (regex-based vuln detection)
  - `src/prompts.py`
- **Demo:** CLI: `python main.py --input "create login"` → generated code string; show auditor finds obvious issues.

### Week 8 — Intermediate representation & analysis
- **Code focus:** AST + data flow analyzers.
- **Files to show:**
  - `src/ast_analyzer.py`
  - `src/dataflow_analyzer.py`
- **Demo:** Run a small code sample through analyzers (can hardcode in a quick script or REPL) to show detected patterns.

### Week 9 — Agentic AI loop
- **Code focus:** Agent + orchestrator with function-calling tools.
- **Files to show:**
  - `src/agent.py`
  - `src/agent_orchestrator.py`
- **Demo:** `python main.py --input "create login"` → shows iterations/actions (even with mocked/vacuous outputs if no API key).

### Week 10 — Optimization & security enforcement
- **Code focus:** Performance optimizer, OWASP enforcement.
- **Files to show:**
  - `src/optimizer.py`
  - `src/security_enforcer.py`
- **Demo:** Show optimizer cache stats, compliance check on a snippet.

### Week 11 — Testing & validation
- **Code focus:** Test suite build-out.
- **Files to show:**
  - `tests/test_suite.py`
- **Demo:** `pytest tests/test_suite.py -q` (allow some tests to xfail if no API key; mark or skip accordingly).

### Week 12 — Evaluation & benchmarking
- **Code focus:** Instrumentation/hooks for metrics; docs for evaluation.
- **Files to show:**
  - `deliverables/week12/EVALUATION.md`
  - Point to metric hooks in `optimizer.py` / orchestrator timing in `agent_orchestrator.py`
- **Demo:** Show sample metrics dict from a run.

### Week 13 — Explainability & visuals
- **Code focus:** Explainability + visualizations.
- **Files to show:**
  - `src/explainability.py`
  - `src/visualizer.py`
- **Demo:** Call a visualization function to produce an HTML heatmap (can open in browser) or print an agent decision tree text.

### Week 14 — Final integration & polish
- **Code focus:** Full integration; everything wired in `frontend.py` and `main.py`.
- **Files to show:**
  - Entire `src/` as final product
  - `README.md`, `USER_GUIDE.md`, `HOW_TO_RUN.md`
- **Demo:** Full happy-path run via Streamlit and CLI.

---
## How to simulate “per-week” code without duplicating files
Instead of cloning code per week, do this when presenting:
1. **Only open/show the files listed for that week.**
2. **Describe upcoming components as “planned”** if they were added later in the final code.
3. **Use small, focused demos** that match that week’s scope (e.g., Week 7: show compiler + basic auditor; don’t show agent yet).
4. **If needed, comment out later-stage imports** temporarily in a copy to avoid errors when demoing early-week scope.

---
## Optional: lightweight week tags (if using git later)
If you put this in git, you can tag milestones:
- `week01`, `week02`, … `week14`
so you can checkout any week’s state. (Not done here, but recommended.)

---
## At-a-glance mapping (week → key code pieces)
- Week 5: `prompts.py`, I/O spec, `main.py` stub
- Week 6: `frontend.py` MVP, validation/error scaffolds
- Week 7: `compiler.py`, `auditor_basic.py`
- Week 8: `ast_analyzer.py`, `dataflow_analyzer.py`
- Week 9: `agent.py`, `agent_orchestrator.py`
- Week 10: `optimizer.py`, `security_enforcer.py`
- Week 11: `tests/test_suite.py`
- Week 12: Metrics hooks + `deliverables/week12/EVALUATION.md`
- Week 13: `explainability.py`, `visualizer.py`
- Week 14: Final integration in `frontend.py` / `main.py`

---
## Tips for demos by week
- **Use fake inputs** if you don’t have an API key; emphasize flow over API calls.
- **Skip/xfail tests** that need the API in Week 11; explain that they pass with a key.
- **Keep UI minimal** for Weeks 6–8 demos; show richer UI only in Week 14.
- **Narrate the evolution:** “This week we added X; next week we’ll add Y.”

---
**Outcome:** By Week 14, the full system (current `src/`) is complete. Earlier weeks show progressive capabilities aligned to the execution plan without needing separate code copies.
