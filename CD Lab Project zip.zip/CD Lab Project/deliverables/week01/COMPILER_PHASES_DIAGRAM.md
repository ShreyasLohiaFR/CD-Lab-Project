# Compiler Phases Overview Diagram

**Week 1 Deliverable**

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    USER INTERFACE (Streamlit)                    │
│  Natural Language Input: "Create a secure login function"       │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│              PHASE 1: NLP PARSING & INTENT EXTRACTION           │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  Intent Extraction Module                                 │  │
│  │  • Parse natural language                                 │  │
│  │  • Extract functionality requirements                     │  │
│  │  • Identify security requirements                        │  │
│  │  • Structure intent as JSON                              │  │
│  └──────────────────────────────────────────────────────────┘  │
│  Output: {                                                      │
│    "functionality": "login with validation",                   │
│    "components": ["authentication", "password"],                 │
│    "security_requirements": ["hashing", "validation"]            │
│  }                                                              │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│         PHASE 2: SECURITY-ENFORCED CODE GENERATION               │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  Code Generator (LLM Integration)                         │  │
│  │  • OpenAI API / LangChain                                │  │
│  │  • Security-enforced system prompts                       │  │
│  │  • OWASP Top 10 guidelines                               │  │
│  │  • Few-shot examples of secure code                      │  │
│  └──────────────────────────────────────────────────────────┘  │
│  Output: Python code (initial generation)                       │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│          PHASE 3: MULTI-LAYER SECURITY AUDITING                  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐         │
│  │ Rule-Based   │  │ AST Analyzer │  │ Data Flow    │         │
│  │ Auditor      │  │              │  │ Analyzer     │         │
│  │ (Regex)      │  │              │  │              │         │
│  └──────────────┘  └──────────────┘  └──────────────┘         │
│         │                │                │                     │
│         └────────────────┴────────────────┘                   │
│                           │                                     │
│                  Vulnerability Report                           │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│            PHASE 4: AGENTIC AI AUTONOMOUS FIXING                │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  Agent Decision Loop                                     │  │
│  │                                                          │  │
│  │  1. Analyze vulnerabilities                             │  │
│  │  2. Decide: ACCEPT / FIX / REGENERATE                  │  │
│  │  3. If FIX: Generate fixed code                         │  │
│  │  4. Re-audit fixed code                                 │  │
│  │  5. Repeat until secure or max iterations (3)          │  │
│  └──────────────────────────────────────────────────────────┘  │
│  Output: Secure, production-ready code                         │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                      FINAL OUTPUT                                │
│  • Secure Python code                                           │
│  • Security audit report                                        │
│  • Vulnerability fixes applied                                   │
│  • OWASP compliance certificate                                 │
└─────────────────────────────────────────────────────────────────┘
```

## Detailed Phase Breakdown

### Phase 1: NLP Parsing & Intent Extraction
- **Input**: Natural language string
- **Technologies**: OpenAI API, LangChain
- **Process**:
  1. Tokenize and parse input
  2. Extract key concepts (functionality, inputs, outputs)
  3. Identify security requirements
  4. Structure as JSON intent
- **Output**: Structured intent object

### Phase 2: Security-Enforced Code Generation
- **Input**: Structured intent
- **Technologies**: OpenAI GPT-4, LangChain
- **Process**:
  1. Construct security-enforced prompt
  2. Include OWASP Top 10 guidelines
  3. Add few-shot secure code examples
  4. Generate code via LLM
- **Output**: Python code string

### Phase 3: Multi-Layer Security Auditing
- **Input**: Generated code
- **Technologies**: Regex, Python AST, Data flow analysis
- **Process**:
  1. **Rule-Based**: Pattern matching for known vulnerabilities
  2. **AST Analysis**: Parse code structure, detect dangerous patterns
  3. **Data Flow**: Track tainted variables to sinks
- **Output**: Vulnerability report with severity and fixes

### Phase 4: Agentic AI Autonomous Fixing
- **Input**: Code + Vulnerability report
- **Technologies**: LangChain Agents, Function Calling
- **Process**:
  1. Agent analyzes vulnerabilities
  2. Autonomous decision: accept, fix, or regenerate
  3. If fix: generate improved code
  4. Re-audit and iterate (max 3 times)
- **Output**: Final secure code

## Data Flow Diagram

```
User Input (NL)
    │
    ├─→ Intent Extraction
    │       │
    │       └─→ Structured Intent
    │               │
    │               └─→ Code Generator
    │                       │
    │                       └─→ Initial Code
    │                               │
    │                               ├─→ Rule-Based Auditor
    │                               ├─→ AST Analyzer
    │                               └─→ Data Flow Analyzer
    │                                       │
    │                                       └─→ Vulnerability Report
    │                                               │
    │                                               └─→ Agent Decision
    │                                                       │
    │                                                       ├─→ ACCEPT → Final Code
    │                                                       ├─→ FIX → Improved Code → Re-audit
    │                                                       └─→ REGENERATE → New Code → Re-audit
```

## Module Interaction Sequence

```
User → Frontend → Orchestrator
                    │
                    ├─→ Compiler (generate code)
                    │
                    ├─→ Auditor (detect vulnerabilities)
                    │
                    ├─→ Agent (decide action)
                    │
                    ├─→ Compiler (fix code) [if needed]
                    │
                    └─→ Final Output
```
