# Problem Definition Document

**Week 1 Deliverable**  
**Student:** Shreyas Prakash Lohia  
**Roll Number:** 24CSB0B70  
**Date:** Week 1

## 1. Problem Statement

Traditional code generation tools (ChatGPT, GitHub Copilot) generate functional code but often overlook security vulnerabilities. Developers must manually review and fix security issues, which is time-consuming and error-prone. There is a critical need for an intelligent compiler that automatically generates secure, production-ready code from natural language descriptions while ensuring compliance with security best practices.

## 2. Problem Context

### 2.1 Current State
- Developers use AI tools to generate code quickly
- Generated code often contains security vulnerabilities
- Manual security auditing is required
- Security fixes are applied reactively (after vulnerabilities are found)

### 2.2 Challenges
- **Security Gap**: AI-generated code lacks built-in security awareness
- **Manual Effort**: Security auditing requires significant manual intervention
- **Knowledge Barrier**: Developers may not be aware of all security best practices
- **Time Constraint**: Security fixes delay development cycles

## 3. Proposed Solution

An **End-to-End Natural Language to Secure Code Compiler with Agentic AI** that:
1. Accepts natural language code requirements
2. Generates secure code using LLM with security-enforced prompts
3. Automatically audits generated code for vulnerabilities
4. Uses agentic AI to autonomously fix detected vulnerabilities
5. Ensures OWASP Top 10 compliance

## 4. Compiler Phases Overview

### Phase 1: Front-End Processing
- **Input**: Natural language description (English)
- **Processing**: 
  - Intent extraction using NLP
  - Semantic analysis of requirements
- **Output**: Structured intent representation

### Phase 2: Code Generation
- **Input**: Structured intent
- **Processing**:
  - LLM-based code generation with security constraints
  - Security-enforced system prompts
- **Output**: Initial code generation

### Phase 3: Security Auditing
- **Input**: Generated code
- **Processing**:
  - Rule-based vulnerability detection (regex patterns)
  - AST-based code analysis
  - Data flow analysis
- **Output**: Vulnerability report

### Phase 4: Agentic AI Loop
- **Input**: Code + Vulnerability report
- **Processing**:
  - Autonomous decision-making
  - Automatic vulnerability fixing
  - Iterative improvement (max 3 iterations)
- **Output**: Secure, production-ready code

## 5. Compiler Phases Diagram

```
┌─────────────────────────────────────────────────────────┐
│              NATURAL LANGUAGE INPUT                      │
│         "Create a login form with validation"            │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│           PHASE 1: NLP PARSING & INTENT EXTRACTION      │
│  • Parse natural language                                │
│  • Extract programming intent                            │
│  • Identify security requirements                        │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│        PHASE 2: SECURITY-ENFORCED CODE GENERATION       │
│  • LLM integration (OpenAI API)                          │
│  • Security-aware prompts                                │
│  • OWASP Top 10 compliance                               │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│          PHASE 3: MULTI-LAYER SECURITY AUDITING         │
│  • Rule-based detection (regex)                         │
│  • AST analysis                                          │
│  • Data flow analysis                                   │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│         PHASE 4: AGENTIC AI AUTONOMOUS FIXING           │
│  • Agent decision-making                                 │
│  • Automatic vulnerability fixing                        │
│  • Iterative improvement loop                            │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│              SECURE CODE OUTPUT                          │
│  • Production-ready code                                 │
│  • Security audit report                                 │
│  • Compliance certificate                                │
└─────────────────────────────────────────────────────────┘
```

## 6. Common Code Vulnerabilities (10+ Types)

1. **SQL Injection**
   - Description: Unvalidated user input in SQL queries
   - Impact: Data breach, unauthorized access
   - Example: `query = "SELECT * FROM users WHERE id = " + user_id`

2. **XSS (Cross-Site Scripting)**
   - Description: Unsanitized user input rendered in HTML
   - Impact: Session hijacking, data theft
   - Example: `element.innerHTML = user_input`

3. **Weak Password Storage**
   - Description: Plain text or weak hashing (MD5, SHA1)
   - Impact: Password compromise
   - Example: `password = "admin123"` or `hashlib.md5(password)`

4. **Hardcoded Secrets**
   - Description: API keys, passwords, tokens in source code
   - Impact: Credential exposure
   - Example: `api_key = "sk-1234567890"`

5. **Missing Input Validation**
   - Description: No validation of user inputs
   - Impact: Various injection attacks
   - Example: Direct use of `request.form.get('input')` without validation

6. **Command Injection**
   - Description: User input in system commands
   - Impact: Remote code execution
   - Example: `os.system("rm " + filename)`

7. **Path Traversal**
   - Description: Unvalidated file paths from user input
   - Impact: Unauthorized file access
   - Example: `open("/path/" + user_input)`

8. **CSRF (Cross-Site Request Forgery)**
   - Description: Missing CSRF tokens in state-changing operations
   - Impact: Unauthorized actions
   - Example: POST endpoint without CSRF protection

9. **Broken Authentication**
   - Description: Weak authentication mechanisms
   - Impact: Unauthorized access
   - Example: Plain text password comparison

10. **Sensitive Data Exposure**
    - Description: Logging or printing sensitive information
    - Impact: Information disclosure
    - Example: `print(f"Password: {password}")`

11. **Insecure Deserialization**
    - Description: Deserializing untrusted data
    - Impact: Remote code execution
    - Example: `pickle.loads(user_data)`

12. **XML External Entity (XXE)**
    - Description: Processing XML with external entities
    - Impact: Information disclosure, SSRF
    - Example: XML parser with external entity resolution

## 7. Motivation for AI-Assisted Secure Code Compilation

### 7.1 Why Security-Aware AI Compilation is Needed

1. **Scale of Vulnerabilities**: Millions of lines of vulnerable code exist
2. **Developer Shortage**: Not enough security experts to review all code
3. **Speed Requirement**: Development cycles are getting faster
4. **Cost of Breaches**: Security breaches cost millions
5. **Compliance**: Regulatory requirements (GDPR, HIPAA) demand secure code
6. **Proactive Security**: Fix vulnerabilities at generation time, not after deployment

### 7.2 Benefits

- **Automated Security**: No manual security review needed
- **Consistency**: Same security standards applied to all generated code
- **Education**: Developers learn security best practices through examples
- **Speed**: Faster development with built-in security
- **Cost Reduction**: Lower cost of security fixes (prevention vs. cure)

## 8. Success Criteria

The compiler should:
1. Generate secure code from natural language
2. Detect 95%+ of common vulnerabilities
3. Automatically fix vulnerabilities without human intervention
4. Achieve <10 second response time
5. Maintain <$0.05 cost per request
6. Ensure OWASP Top 10 compliance

## 9. Conclusion

This project addresses a critical gap in AI-assisted code generation by integrating security awareness directly into the compilation process. By combining NLP, LLM-based generation, automated auditing, and agentic AI, we can produce secure, production-ready code automatically, reducing security risks and development time.
