"""
Visualization module for code analysis and security metrics.
"""
import logging
from typing import Dict, Any, List, Optional
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.pyplot as plt
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from .utils import logger


class Visualizer:
    """Generate visualizations for code analysis and security metrics."""
    
    def __init__(self):
        """Initialize visualizer."""
        logger.info("Visualizer initialized")
    
    def create_vulnerability_heatmap(self, vulnerabilities: List[Dict[str, Any]], 
                                     output_path: Optional[str] = None) -> str:
        """Create vulnerability heatmap by type and severity."""
        if not vulnerabilities:
            return "No vulnerabilities to visualize"
        
        # Count vulnerabilities by type and severity
        vuln_data = {}
        for vuln in vulnerabilities:
            vuln_type = vuln.get("type", "unknown")
            severity = vuln.get("severity", "low")
            
            if vuln_type not in vuln_data:
                vuln_data[vuln_type] = {"high": 0, "medium": 0, "low": 0, "critical": 0}
            
            vuln_data[vuln_type][severity] = vuln_data[vuln_type].get(severity, 0) + 1
        
        # Create heatmap data
        types = list(vuln_data.keys())
        severities = ["critical", "high", "medium", "low"]
        
        z_data = []
        for vuln_type in types:
            row = [vuln_data[vuln_type].get(sev, 0) for sev in severities]
            z_data.append(row)
        
        # Create plotly heatmap
        fig = go.Figure(data=go.Heatmap(
            z=z_data,
            x=severities,
            y=types,
            colorscale='Reds',
            text=z_data,
            texttemplate='%{text}',
            textfont={"size": 12}
        ))
        
        fig.update_layout(
            title="Vulnerability Heatmap by Type and Severity",
            xaxis_title="Severity",
            yaxis_title="Vulnerability Type",
            width=800,
            height=400
        )
        
        if output_path:
            fig.write_html(output_path)
            logger.info(f"Heatmap saved to {output_path}")
        
        return fig.to_html(include_plotlyjs='cdn')
    
    def create_security_score_chart(self, scores: List[int], output_path: Optional[str] = None) -> str:
        """Create security score trend chart."""
        fig = go.Figure()
        
        fig.add_trace(go.Scatter(
            x=list(range(1, len(scores) + 1)),
            y=scores,
            mode='lines+markers',
            name='Security Score',
            line=dict(color='green', width=2),
            marker=dict(size=8)
        ))
        
        # Add threshold line
        fig.add_hline(y=80, line_dash="dash", line_color="orange", 
                     annotation_text="Target (80)")
        
        fig.update_layout(
            title="Security Score Trend",
            xaxis_title="Iteration",
            yaxis_title="Security Score",
            yaxis=dict(range=[0, 100]),
            width=800,
            height=400
        )
        
        if output_path:
            fig.write_html(output_path)
        
        return fig.to_html(include_plotlyjs='cdn')
    
    def create_agent_decision_tree(self, actions: List[str], output_path: Optional[str] = None) -> str:
        """Create visualization of agent decision tree."""
        # Simple text-based tree (could be enhanced with graphviz)
        tree_text = []
        tree_text.append("Agent Decision Tree:")
        tree_text.append("=" * 40)
        
        for i, action in enumerate(actions, 1):
            indent = "  " * (i - 1)
            tree_text.append(f"{indent}└─ {action}")
        
        tree_text.append("=" * 40)
        
        result = "\n".join(tree_text)
        
        if output_path:
            with open(output_path, 'w') as f:
                f.write(result)
            logger.info(f"Decision tree saved to {output_path}")
        
        return result
    
    def create_code_generation_flowchart(self, steps: List[str], output_path: Optional[str] = None) -> str:
        """Create flowchart of code generation process."""
        flowchart = []
        flowchart.append("Code Generation Flow:")
        flowchart.append("=" * 40)
        
        for i, step in enumerate(steps, 1):
            if i < len(steps):
                flowchart.append(f"  {step}")
                flowchart.append("    ↓")
            else:
                flowchart.append(f"  {step}")
        
        flowchart.append("=" * 40)
        
        result = "\n".join(flowchart)
        
        if output_path:
            with open(output_path, 'w') as f:
                f.write(result)
            logger.info(f"Flowchart saved to {output_path}")
        
        return result
    
    def create_metrics_dashboard(self, metrics: Dict[str, Any], 
                                 output_path: Optional[str] = None) -> str:
        """Create comprehensive metrics dashboard."""
        fig = make_subplots(
            rows=2, cols=2,
            subplot_titles=('Response Time', 'Security Score', 'Vulnerability Count', 'Cache Hit Ratio'),
            specs=[[{"type": "indicator"}, {"type": "indicator"}],
                   [{"type": "bar"}, {"type": "pie"}]]
        )
        
        # Response time gauge
        response_time = metrics.get("response_time", 0)
        fig.add_trace(go.Indicator(
            mode="gauge+number",
            value=response_time,
            title={"text": "Response Time (s)"},
            gauge={"axis": {"range": [None, 10]},
                   "bar": {"color": "green" if response_time < 10 else "red"},
                   "steps": [{"range": [0, 5], "color": "lightgreen"},
                            {"range": [5, 10], "color": "yellow"}],
                   "threshold": {"line": {"color": "red", "width": 4},
                               "thickness": 0.75, "value": 10}}
        ), row=1, col=1)
        
        # Security score gauge
        security_score = metrics.get("security_score", 0)
        fig.add_trace(go.Indicator(
            mode="gauge+number",
            value=security_score,
            title={"text": "Security Score"},
            gauge={"axis": {"range": [0, 100]},
                   "bar": {"color": "green" if security_score >= 80 else "orange"},
                   "steps": [{"range": [0, 50], "color": "red"},
                            {"range": [50, 80], "color": "yellow"},
                            {"range": [80, 100], "color": "green"}]}
        ), row=1, col=2)
        
        # Vulnerability count bar
        vuln_counts = metrics.get("vulnerability_counts", {})
        if vuln_counts:
            fig.add_trace(go.Bar(
                x=list(vuln_counts.keys()),
                y=list(vuln_counts.values()),
                name="Vulnerabilities"
            ), row=2, col=1)
        
        # Cache hit ratio pie
        cache_hits = metrics.get("cache_hits", 0)
        cache_misses = metrics.get("cache_misses", 0)
        if cache_hits + cache_misses > 0:
            fig.add_trace(go.Pie(
                labels=["Cache Hits", "Cache Misses"],
                values=[cache_hits, cache_misses],
                name="Cache"
            ), row=2, col=2)
        
        fig.update_layout(
            title="Performance & Security Metrics Dashboard",
            height=800,
            showlegend=False
        )
        
        if output_path:
            fig.write_html(output_path)
            logger.info(f"Dashboard saved to {output_path}")
        
        return fig.to_html(include_plotlyjs='cdn')
    
    def create_compliance_graph(self, compliance: Dict[str, Any], 
                               output_path: Optional[str] = None) -> str:
        """Create OWASP compliance visualization."""
        guidelines = compliance.get("guidelines_met", [])
        violations = compliance.get("violations", [])
        
        fig = go.Figure()
        
        fig.add_trace(go.Bar(
            x=["Compliant", "Non-Compliant"],
            y=[len(guidelines), len(violations)],
            marker_color=["green", "red"]
        ))
        
        fig.update_layout(
            title="OWASP Top 10 Compliance Status",
            xaxis_title="Status",
            yaxis_title="Count",
            width=600,
            height=400
        )
        
        if output_path:
            fig.write_html(output_path)
        
        return fig.to_html(include_plotlyjs='cdn')


# Example usage
if __name__ == "__main__":
    visualizer = Visualizer()
    
    vulnerabilities = [
        {"type": "sql_injection", "severity": "high"},
        {"type": "xss", "severity": "medium"}
    ]
    
    print(visualizer.create_vulnerability_heatmap(vulnerabilities))
