"""
Agentic AI implementation with function calling capabilities.
"""
import os
import logging
from typing import Dict, Any, List, Optional, Callable
from dotenv import load_dotenv
from .compiler import CodeCompiler
from .auditor_basic import BasicAuditor
from .utils import logger

load_dotenv()


class SecurityAgent:
    """Autonomous security agent with function calling."""
    
    def __init__(self, model_name: str = "gpt-4-turbo-preview"):
        """Initialize the security agent."""
        # NOTE: The agent loop can run in OFFLINE_MODE (no OpenAI calls).
        # Code generation is handled by CodeCompiler which will switch to templates if needed.
        self.llm = None
        self.compiler = CodeCompiler(model_name=model_name)
        self.auditor = BasicAuditor()
        logger.info("SecurityAgent initialized")
    
    def decide_action(self, code: str, vulnerabilities: List[Dict[str, Any]], 
                     iteration: int, max_iterations: int = 3) -> str:
        """Agent decides next action based on current state."""
        if not vulnerabilities:
            return "ACCEPT"
        
        if iteration >= max_iterations:
            return "ACCEPT"  # Max iterations reached
        
        high_severity = [v for v in vulnerabilities if v["severity"] in ["high", "critical"]]
        if high_severity:
            return "FIX"
        
        return "ACCEPT"
    
    def execute_agent_loop(self, user_input: str, max_iterations: int = 3) -> Dict[str, Any]:
        """Execute autonomous agent loop."""
        logger.info(f"Starting agent loop for: {user_input[:50]}...")
        
        iteration = 0
        current_code = ""
        all_vulnerabilities = []
        actions_taken = []
        
        while iteration < max_iterations:
            iteration += 1
            logger.info(f"Agent iteration {iteration}/{max_iterations}")
            
            # Step 1: Generate code
            should_generate = (iteration == 1) or (bool(actions_taken) and ("REGENERATE" in actions_taken[-1]))
            if should_generate:
                current_code = self.compiler.generate_code(user_input)
                actions_taken.append(f"Iteration {iteration}: Generated code")
            
            # Step 2: Audit code
            vulnerabilities = self.auditor.audit(current_code)
            all_vulnerabilities.extend(vulnerabilities)
            actions_taken.append(f"Iteration {iteration}: Audited code - found {len(vulnerabilities)} vulnerabilities")
            
            # Step 3: Agent decision
            decision = self.decide_action(current_code, vulnerabilities, iteration, max_iterations)
            actions_taken.append(f"Iteration {iteration}: Decision = {decision}")
            
            if decision == "ACCEPT":
                break
            
            # Step 4: Fix code
            if decision == "FIX":
                vuln_summary = "\n".join([f"- {v['description']}" for v in vulnerabilities[:3]])
                current_code = self.compiler.generate_code(
                    f"Fix the following code. Vulnerabilities to fix: {vuln_summary}\n\nOriginal request: {user_input}\n\nCode to fix:\n{current_code}"
                )
                actions_taken.append(f"Iteration {iteration}: Fixed code")
        
        # Final audit
        final_vulnerabilities = self.auditor.audit(current_code)
        is_secure = len([v for v in final_vulnerabilities if v["severity"] in ["high", "critical"]]) == 0
        
        result = {
            "code": current_code,
            "vulnerabilities": final_vulnerabilities,
            "is_secure": is_secure,
            "iterations": iteration,
            "actions_taken": actions_taken,
            "security_score": max(0, 100 - len(final_vulnerabilities) * 10)
        }
        
        logger.info(f"Agent loop completed: {iteration} iterations, {len(final_vulnerabilities)} vulnerabilities")
        return result


# Example usage
if __name__ == "__main__":
    agent = SecurityAgent()
    result = agent.execute_agent_loop("Create a login function with username and password")
    print(f"Generated Code:\n{result['code']}")
    print(f"\nSecurity Score: {result['security_score']}/100")
    print(f"Vulnerabilities: {len(result['vulnerabilities'])}")
