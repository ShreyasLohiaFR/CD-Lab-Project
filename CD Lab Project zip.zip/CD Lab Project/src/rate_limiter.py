"""
Rate limiting module to prevent API abuse and control costs.
"""
import time
import logging
from typing import Dict, Any, Optional, Tuple
from collections import defaultdict, deque
from datetime import datetime, timedelta
from .utils import logger


class RateLimiter:
    """Rate limiter for API calls and requests."""
    
    def __init__(self, max_requests_per_minute: int = 10, max_requests_per_hour: int = 100):
        """Initialize rate limiter."""
        self.max_requests_per_minute = max_requests_per_minute
        self.max_requests_per_hour = max_requests_per_hour
        self.request_times: Dict[str, deque] = defaultdict(deque)
        self.blocked_ips: Dict[str, datetime] = {}
        self.block_duration = timedelta(minutes=5)
        logger.info(f"RateLimiter initialized: {max_requests_per_minute}/min, {max_requests_per_hour}/hour")
    
    def is_allowed(self, identifier: str = "default") -> Tuple[bool, Optional[str]]:
        """Check if request is allowed. Returns (is_allowed, reason_if_blocked)."""
        now = datetime.now()
        
        # Check if identifier is blocked
        if identifier in self.blocked_ips:
            block_until = self.blocked_ips[identifier]
            if now < block_until:
                remaining = (block_until - now).total_seconds()
                return False, f"Rate limit exceeded. Blocked for {remaining:.0f} more seconds"
            else:
                # Unblock
                del self.blocked_ips[identifier]
        
        # Get request history
        request_history = self.request_times[identifier]
        now_timestamp = time.time()
        
        # Remove old requests (older than 1 hour)
        while request_history and now_timestamp - request_history[0] > 3600:
            request_history.popleft()
        
        # Check hourly limit
        if len(request_history) >= self.max_requests_per_hour:
            self.blocked_ips[identifier] = now + self.block_duration
            return False, f"Hourly rate limit exceeded ({self.max_requests_per_hour} requests/hour)"
        
        # Check per-minute limit (last 60 seconds)
        recent_requests = [t for t in request_history if now_timestamp - t < 60]
        if len(recent_requests) >= self.max_requests_per_minute:
            return False, f"Rate limit exceeded ({self.max_requests_per_minute} requests/minute)"
        
        # Allow request and record time
        request_history.append(now_timestamp)
        return True, None
    
    def get_stats(self, identifier: str = "default") -> Dict[str, Any]:
        """Get rate limiting statistics for identifier."""
        request_history = self.request_times.get(identifier, deque())
        now_timestamp = time.time()
        
        # Count requests in last minute
        recent_minute = [t for t in request_history if now_timestamp - t < 60]
        
        # Count requests in last hour
        recent_hour = [t for t in request_history if now_timestamp - t < 3600]
        
        return {
            "requests_last_minute": len(recent_minute),
            "requests_last_hour": len(recent_hour),
            "max_per_minute": self.max_requests_per_minute,
            "max_per_hour": self.max_requests_per_hour,
            "is_blocked": identifier in self.blocked_ips,
            "blocked_until": self.blocked_ips.get(identifier).isoformat() if identifier in self.blocked_ips else None
        }
    
    def reset(self, identifier: str = "default") -> None:
        """Reset rate limit for identifier."""
        if identifier in self.request_times:
            del self.request_times[identifier]
        if identifier in self.blocked_ips:
            del self.blocked_ips[identifier]
        logger.info(f"Rate limit reset for {identifier}")


# Example usage
if __name__ == "__main__":
    limiter = RateLimiter(max_requests_per_minute=5, max_requests_per_hour=50)
    
    # Test rate limiting
    for i in range(7):
        allowed, reason = limiter.is_allowed("test_user")
        print(f"Request {i+1}: Allowed={allowed}, Reason={reason}")
        time.sleep(0.1)
    
    print(f"\nStats: {limiter.get_stats('test_user')}")
