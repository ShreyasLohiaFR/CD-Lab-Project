"""
Code formatting and quality enhancement module.
"""
import re
import logging
from typing import Dict, Any, Optional, List
from .utils import logger


class CodeFormatter:
    """Format and enhance generated code quality."""
    
    def __init__(self):
        """Initialize code formatter."""
        logger.info("CodeFormatter initialized")
    
    def format_code(self, code: str) -> str:
        """Format code for better readability."""
        # Remove excessive blank lines
        code = re.sub(r'\n{3,}', '\n\n', code)
        
        # Ensure proper spacing around operators
        code = re.sub(r'(\w)([+\-*/=<>!]+)(\w)', r'\1 \2 \3', code)
        code = re.sub(r'(\w)([+\-*/=<>!]+)(\s)', r'\1 \2\3', code)
        code = re.sub(r'(\s)([+\-*/=<>!]+)(\w)', r'\1\2 \3', code)
        
        # Fix common spacing issues
        code = re.sub(r'\(\s+', '(', code)
        code = re.sub(r'\s+\)', ')', code)
        code = re.sub(r'\[\s+', '[', code)
        code = re.sub(r'\s+\]', ']', code)
        code = re.sub(r'\{\s+', '{', code)
        code = re.sub(r'\s+\}', '}', code)
        
        # Ensure newline at end of file
        if code and not code.endswith('\n'):
            code += '\n'
        
        return code
    
    def add_docstrings(self, code: str) -> str:
        """Add docstrings to functions that don't have them."""
        lines = code.split('\n')
        result = []
        i = 0
        
        while i < len(lines):
            line = lines[i]
            result.append(line)
            
            # Check if this is a function definition
            if re.match(r'^\s*def\s+\w+\s*\(', line):
                # Check if next line is a docstring
                if i + 1 < len(lines) and '"""' not in lines[i + 1]:
                    indent = len(line) - len(line.lstrip())
                    result.append(' ' * (indent + 4) + '"""Docstring."""')
            
            i += 1
        
        return '\n'.join(result)
    
    def enhance_code_quality(self, code: str) -> Dict[str, Any]:
        """Analyze and enhance code quality."""
        analysis = {
            "has_docstrings": bool(re.search(r'""".*"""', code, re.DOTALL)),
            "has_type_hints": bool(re.search(r'->\s*\w+:', code)),
            "has_comments": bool(re.search(r'#', code)),
            "line_count": len(code.split('\n')),
            "function_count": len(re.findall(r'^\s*def\s+', code, re.MULTILINE)),
            "class_count": len(re.findall(r'^\s*class\s+', code, re.MULTILINE)),
            "complexity_score": self._calculate_complexity(code)
        }
        
        return analysis
    
    def _calculate_complexity(self, code: str) -> int:
        """Calculate simple complexity score."""
        complexity = 0
        
        # Count control flow statements
        complexity += len(re.findall(r'\bif\b', code))
        complexity += len(re.findall(r'\bfor\b', code))
        complexity += len(re.findall(r'\bwhile\b', code))
        complexity += len(re.findall(r'\btry\b', code))
        complexity += len(re.findall(r'\bexcept\b', code))
        
        return complexity
    
    def suggest_improvements(self, code: str) -> List[str]:
        """Suggest code improvements."""
        suggestions = []
        analysis = self.enhance_code_quality(code)
        
        if not analysis["has_docstrings"]:
            suggestions.append("Add docstrings to functions")
        
        if not analysis["has_type_hints"]:
            suggestions.append("Consider adding type hints")
        
        if analysis["complexity_score"] > 20:
            suggestions.append("Code complexity is high - consider refactoring")
        
        if not analysis["has_comments"]:
            suggestions.append("Add comments for complex logic")
        
        return suggestions


# Example usage
if __name__ == "__main__":
    formatter = CodeFormatter()
    
    test_code = "def func(x,y):\n    return x+y"
    formatted = formatter.format_code(test_code)
    print("Formatted code:")
    print(formatted)
    
    analysis = formatter.enhance_code_quality(test_code)
    print(f"\nQuality analysis: {analysis}")
