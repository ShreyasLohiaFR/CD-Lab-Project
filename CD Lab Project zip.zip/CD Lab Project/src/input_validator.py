"""
Input validation and sanitization module.
"""
import re
import logging
from typing import Dict, Any, Tuple, Optional
from .utils import logger


class InputValidator:
    """Validate and sanitize user inputs."""
    
    def __init__(self):
        """Initialize validator."""
        self.max_input_length = 1000
        self.min_input_length = 10
        self.dangerous_patterns = [
            r'eval\s*\(',
            r'exec\s*\(',
            r'__import__',
            r'compile\s*\(',
            r'open\s*\([^)]*[\'"]/etc/',
            r'subprocess\.call',
            r'os\.system',
        ]
        logger.info("InputValidator initialized")
    
    def validate_user_input(self, user_input: str) -> Tuple[bool, Optional[str]]:
        """Validate user input and return (is_valid, error_message)."""
        if not user_input or not isinstance(user_input, str):
            return False, "Input must be a non-empty string"
        
        # Check length
        if len(user_input) < self.min_input_length:
            return False, f"Input too short (minimum {self.min_input_length} characters)"
        
        if len(user_input) > self.max_input_length:
            return False, f"Input too long (maximum {self.max_input_length} characters)"
        
        # Check for dangerous patterns (potential code injection attempts)
        for pattern in self.dangerous_patterns:
            if re.search(pattern, user_input, re.IGNORECASE):
                logger.warning(f"Dangerous pattern detected in input: {pattern}")
                return False, "Input contains potentially dangerous code patterns"
        
        # Check for excessive special characters (potential obfuscation)
        special_char_ratio = len(re.findall(r'[^\w\s]', user_input)) / len(user_input)
        if special_char_ratio > 0.3:
            return False, "Input contains too many special characters"
        
        return True, None
    
    def sanitize_input(self, user_input: str) -> str:
        """Sanitize user input (remove potentially harmful content)."""
        # Remove null bytes
        sanitized = user_input.replace('\x00', '')
        
        # Remove control characters except newlines and tabs
        sanitized = re.sub(r'[\x00-\x08\x0b-\x0c\x0e-\x1f]', '', sanitized)
        
        # Trim whitespace
        sanitized = sanitized.strip()
        
        # Limit length
        if len(sanitized) > self.max_input_length:
            sanitized = sanitized[:self.max_input_length]
        
        return sanitized
    
    def validate_code_output(self, code: str) -> Tuple[bool, Optional[str]]:
        """Validate generated code output."""
        if not code or not isinstance(code, str):
            return False, "Generated code must be a non-empty string"
        
        if len(code) > 50000:  # Reasonable limit for generated code
            return False, "Generated code exceeds maximum length"
        
        # Check for syntax errors (basic check)
        try:
            compile(code, '<string>', 'exec')
        except SyntaxError as e:
            logger.warning(f"Generated code has syntax error: {e}")
            return False, f"Generated code has syntax errors: {str(e)}"
        
        return True, None
    
    def get_validation_stats(self, user_input: str) -> Dict[str, Any]:
        """Get statistics about input for analysis."""
        return {
            "length": len(user_input),
            "word_count": len(user_input.split()),
            "has_special_chars": bool(re.search(r'[^\w\s]', user_input)),
            "has_numbers": bool(re.search(r'\d', user_input)),
            "estimated_complexity": self._estimate_complexity(user_input)
        }
    
    def _estimate_complexity(self, user_input: str) -> str:
        """Estimate complexity of the request."""
        word_count = len(user_input.split())
        if word_count < 10:
            return "simple"
        elif word_count < 30:
            return "medium"
        else:
            return "complex"


# Example usage
if __name__ == "__main__":
    validator = InputValidator()
    
    # Test validation
    test_input = "Create a login function"
    is_valid, error = validator.validate_user_input(test_input)
    print(f"Valid: {is_valid}, Error: {error}")
    
    # Test sanitization
    dirty_input = "Create a function\x00 with eval()"
    clean = validator.sanitize_input(dirty_input)
    print(f"Sanitized: {clean}")
