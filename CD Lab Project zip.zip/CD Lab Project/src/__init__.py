"""
Secure Code Compiler - Source Package
"""
__version__ = "1.0.0"
