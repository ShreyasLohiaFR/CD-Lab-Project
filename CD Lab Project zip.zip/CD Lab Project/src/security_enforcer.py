"""
Security enforcement module for OWASP Top 10 compliance.
"""
import logging
from typing import List, Dict, Any
from .prompts import get_owasp_top10_guidelines, get_security_constraints
from .utils import logger


class SecurityEnforcer:
    """Enforce security policies and OWASP Top 10 compliance."""
    
    def __init__(self):
        """Initialize security enforcer."""
        self.owasp_guidelines = get_owasp_top10_guidelines()
        self.security_constraints = get_security_constraints()
        logger.info("SecurityEnforcer initialized")
    
    def enforce_owasp_compliance(self, code: str) -> Dict[str, Any]:
        """Check and enforce OWASP Top 10 compliance."""
        compliance_report = {
            "compliant": True,
            "violations": [],
            "guidelines_met": [],
            "score": 100
        }
        
        # Check each OWASP guideline
        for guideline_id, guideline_desc in self.owasp_guidelines.items():
            is_compliant = self._check_guideline_compliance(code, guideline_id)
            
            if is_compliant:
                compliance_report["guidelines_met"].append(guideline_id)
            else:
                compliance_report["compliant"] = False
                compliance_report["violations"].append({
                    "guideline": guideline_id,
                    "description": guideline_desc,
                    "severity": "high"
                })
        
        # Calculate compliance score
        total_guidelines = len(self.owasp_guidelines)
        met_guidelines = len(compliance_report["guidelines_met"])
        compliance_report["score"] = int((met_guidelines / total_guidelines) * 100)
        
        logger.info(f"OWASP compliance check: {compliance_report['score']}% compliant")
        return compliance_report
    
    def _check_guideline_compliance(self, code: str, guideline_id: str) -> bool:
        """Check if code complies with specific OWASP guideline."""
        # Simplified compliance checks
        checks = {
            "A01:2021-Broken Access Control": self._check_access_control,
            "A02:2021-Cryptographic Failures": self._check_cryptography,
            "A03:2021-Injection": self._check_injection,
            "A04:2021-Insecure Design": self._check_design,
            "A05:2021-Security Misconfiguration": self._check_configuration,
            "A06:2021-Vulnerable Components": self._check_components,
            "A07:2021-Authentication Failures": self._check_authentication,
            "A08:2021-Software and Data Integrity": self._check_integrity,
            "A09:2021-Security Logging Failures": self._check_logging,
            "A10:2021-Server-Side Request Forgery": self._check_ssrf
        }
        
        check_func = checks.get(guideline_id)
        if check_func:
            return check_func(code)
        
        return True  # Default to compliant if no specific check
    
    def _check_access_control(self, code: str) -> bool:
        """Check for proper access control."""
        # Look for authorization checks
        auth_keywords = ["authorize", "permission", "role", "access", "check"]
        return any(keyword in code.lower() for keyword in auth_keywords) or \
               "def" not in code  # No functions = no access control needed
    
    def _check_cryptography(self, code: str) -> bool:
        """Check for proper cryptographic practices."""
        # Check for weak hashing
        weak_hashes = ["md5", "sha1"]
        strong_hashes = ["bcrypt", "argon2", "scrypt", "pbkdf2"]
        
        code_lower = code.lower()
        has_weak = any(hash in code_lower for hash in weak_hashes)
        has_strong = any(hash in code_lower for hash in strong_hashes)
        
        return not has_weak or has_strong
    
    def _check_injection(self, code: str) -> bool:
        """Check for injection vulnerabilities."""
        # Check for parameterized queries
        dangerous_patterns = [
            "execute('",
            "execute(\"",
            "query = \"",
            "query = '"
        ]
        
        code_lower = code.lower()
        has_dangerous = any(pattern in code_lower for pattern in dangerous_patterns)
        has_safe = "?" in code or "%s" in code or "parameter" in code_lower
        
        return not has_dangerous or has_safe
    
    def _check_design(self, code: str) -> bool:
        """Check for secure design principles."""
        # Basic check: code should have some structure
        return "def " in code or "class " in code
    
    def _check_configuration(self, code: str) -> bool:
        """Check for secure configuration."""
        # Check for hardcoded secrets
        secret_patterns = ["password =", "api_key =", "secret =", "token ="]
        code_lower = code.lower()
        has_secrets = any(pattern in code_lower for pattern in secret_patterns)
        
        return not has_secrets or "os.getenv" in code or "os.environ" in code
    
    def _check_components(self, code: str) -> bool:
        """Check for vulnerable components."""
        # This would typically check dependencies, simplified here
        return True
    
    def _check_authentication(self, code: str) -> bool:
        """Check for proper authentication."""
        # Check for password hashing
        code_lower = code.lower()
        if "password" in code_lower:
            return "hash" in code_lower or "bcrypt" in code_lower or "argon2" in code_lower
        return True
    
    def _check_integrity(self, code: str) -> bool:
        """Check for data integrity."""
        # Basic check
        return True
    
    def _check_logging(self, code: str) -> bool:
        """Check for security logging."""
        # Check for logging
        return "logging" in code.lower() or "log" in code.lower()
    
    def _check_ssrf(self, code: str) -> bool:
        """Check for SSRF vulnerabilities."""
        # Check for URL validation
        code_lower = code.lower()
        if "request" in code_lower or "url" in code_lower:
            return "validate" in code_lower or "sanitize" in code_lower
        return True
    
    def enforce_constraints(self, code: str) -> List[str]:
        """Enforce security constraints and return violations."""
        violations = []
        
        for constraint in self.security_constraints:
            if not self._check_constraint(code, constraint):
                violations.append(constraint)
        
        return violations
    
    def _check_constraint(self, code: str, constraint: str) -> bool:
        """Check if code meets a specific constraint."""
        code_lower = code.lower()
        
        if "hardcoded" in constraint.lower():
            return not ("password = '" in code_lower or "api_key = '" in code_lower)
        elif "validation" in constraint.lower():
            return "validate" in code_lower or "check" in code_lower
        elif "parameterized" in constraint.lower():
            return "?" in code or "%s" in code or "parameter" in code_lower
        elif "hashing" in constraint.lower():
            return "bcrypt" in code_lower or "argon2" in code_lower or "hash" in code_lower
        elif "xss" in constraint.lower():
            return "escape" in code_lower or "sanitize" in code_lower
        elif "csrf" in constraint.lower():
            return "csrf" in code_lower or "token" in code_lower
        
        return True  # Default to compliant


# Example usage
if __name__ == "__main__":
    enforcer = SecurityEnforcer()
    
    test_code = """
    def login(username, password):
        if password == "admin123":
            return True
        return False
    """
    
    compliance = enforcer.enforce_owasp_compliance(test_code)
    print(f"OWASP Compliance Score: {compliance['score']}%")
    print(f"Violations: {len(compliance['violations'])}")
