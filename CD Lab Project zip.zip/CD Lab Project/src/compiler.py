"""
Code generation module using LLM integration.
"""
import os
import logging
from typing import Dict, Any, Optional
from dotenv import load_dotenv
from .prompts import SECURITY_CODE_GENERATION_PROMPT, INTENT_EXTRACTION_PROMPT
from .utils import logger

load_dotenv()


class CodeCompiler:
    """Compiler that generates secure code from natural language."""
    
    def __init__(self, model_name: str = "gpt-4-turbo-preview", temperature: float = 0.7):
        """Initialize the compiler with OpenAI model."""
        self.offline_mode = os.getenv("OFFLINE_MODE", "false").lower() in ("1", "true", "yes", "on")
        api_key = os.getenv("OPENAI_API_KEY", "")

        if self.offline_mode or not api_key.strip():
            self.llm = None
            logger.warning("CodeCompiler running in OFFLINE_MODE (no OpenAI calls).")
        else:
            # Import lazily so OFFLINE_MODE does not require these packages.
            try:
                from langchain_openai import ChatOpenAI
            except ModuleNotFoundError:
                # Allow the app to run even if optional deps aren't installed yet.
                self.offline_mode = True
                self.llm = None
                logger.warning(
                    "langchain_openai is not installed; switching to OFFLINE_MODE (no OpenAI calls)."
                )
            else:
                self.llm = ChatOpenAI(
                    model_name=model_name,
                    temperature=temperature,
                    openai_api_key=api_key
                )
        self.model_name = model_name
        logger.info(f"CodeCompiler initialized with model: {model_name}")
    
    def extract_intent(self, user_input: str) -> Dict[str, Any]:
        """Extract programming intent from natural language."""
        if self.llm is None:
            # Lightweight heuristic intent extraction (offline)
            text = (user_input or "").strip()
            lower = text.lower()
            components = []
            if any(k in lower for k in ["login", "auth", "authenticate", "password"]):
                components.append("authentication")
            if any(k in lower for k in ["database", "sql", "query", "sqlite", "postgres", "mysql"]):
                components.append("database")
            if any(k in lower for k in ["file", "upload", "download"]):
                components.append("file_handling")
            if any(k in lower for k in ["api", "endpoint", "http", "request"]):
                components.append("api")
            return {
                "functionality": text,
                "components": components,
                "security_requirements": [
                    "input_validation",
                    "secure_defaults",
                    "no_hardcoded_secrets",
                ],
                "inputs": [],
                "outputs": [],
            }
        try:
            from langchain.schema import HumanMessage, SystemMessage
            prompt = INTENT_EXTRACTION_PROMPT.format(user_input=user_input)
            messages = [
                SystemMessage(content="You are an expert at analyzing programming requirements."),
                HumanMessage(content=prompt)
            ]
            
            response = self.llm.invoke(messages)
            # Parse JSON response (simplified - in production, use proper JSON parsing)
            intent_data = self._parse_intent_response(response.content)
            logger.info(f"Intent extracted: {intent_data.get('functionality', 'Unknown')}")
            return intent_data
        except Exception as e:
            logger.error(f"Error extracting intent: {e}")
            # If the LLM is unavailable (quota/network/etc.), continue in offline mode.
            self.offline_mode = True
            self.llm = None
            return {
                "functionality": user_input,
                "components": [],
                "security_requirements": [],
                "inputs": [],
                "outputs": []
            }
    
    def _parse_intent_response(self, response: str) -> Dict[str, Any]:
        """Parse intent response from LLM."""
        # Simple JSON extraction (in production, use proper JSON parser)
        import json
        import re
        
        # Try to extract JSON from response
        json_match = re.search(r'\{.*\}', response, re.DOTALL)
        if json_match:
            try:
                return json.loads(json_match.group())
            except:
                pass
        
        # Fallback: return structured data
        return {
            "functionality": response[:200],
            "components": [],
            "security_requirements": ["input_validation", "secure_authentication"],
            "inputs": [],
            "outputs": []
        }
    
    def generate_code(self, user_input: str, intent: Optional[Dict[str, Any]] = None) -> str:
        """Generate secure code from natural language input."""
        if self.llm is None:
            if intent is None:
                intent = self.extract_intent(user_input)
            return self._generate_offline_template(user_input=user_input, intent=intent)
        try:
            from langchain.schema import HumanMessage, SystemMessage
            if intent is None:
                intent = self.extract_intent(user_input)
            # Intent extraction may have switched us to offline mode.
            if self.llm is None:
                return self._generate_offline_template(user_input=user_input, intent=intent)
            
            prompt = SECURITY_CODE_GENERATION_PROMPT.format(user_input=user_input)
            messages = [
                SystemMessage(content="You are a security-aware code generator. Always generate secure, production-ready code."),
                HumanMessage(content=prompt)
            ]
            
            response = self.llm.invoke(messages)
            code = self._extract_code_from_response(response.content)
            
            logger.info(f"Code generated successfully ({len(code)} characters)")
            return code
        except Exception as e:
            logger.error(f"Error generating code: {e}")
            # Fallback to offline templates by default.
            fallback = os.getenv("OFFLINE_FALLBACK", "true").lower() in ("1", "true", "yes", "on")
            if fallback:
                self.offline_mode = True
                self.llm = None
                if intent is None:
                    intent = self.extract_intent(user_input)
                logger.warning("Falling back to OFFLINE_MODE template generation.")
                return self._generate_offline_template(user_input=user_input, intent=intent)

            return f"# Error generating code: {str(e)}\n# Please check your API key and try again."

    def _generate_offline_template(self, user_input: str, intent: Dict[str, Any]) -> str:
        """Generate secure template code without calling an LLM."""
        text = (user_input or "").strip()
        lower = text.lower()

        header = f'''"""
OFFLINE_MODE TEMPLATE OUTPUT

Original request:
{text}

Note:
- This output was generated WITHOUT OpenAI (no API calls).
- It is a secure starting point; customize for your app/database/framework.
"""
'''

        if any(k in lower for k in ["login", "authenticate", "auth", "password"]):
            return header + r'''
from __future__ import annotations

import base64
import hmac
import os
from dataclasses import dataclass
from hashlib import pbkdf2_hmac
from typing import Optional


PBKDF2_ITERATIONS = 210_000
SALT_BYTES = 16
DKLEN = 32


def _hash_password(password: str, salt: bytes) -> bytes:
    if not isinstance(password, str) or len(password) < 8:
        raise ValueError("Password must be a string with length >= 8")
    return pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS, dklen=DKLEN)


def hash_password_for_storage(password: str) -> str:
    """
    Returns a storage string: base64(salt) + "." + base64(derived_key)
    Store this value in DB; never store plaintext passwords.
    """
    salt = os.urandom(SALT_BYTES)
    dk = _hash_password(password, salt)
    return f"{base64.b64encode(salt).decode()}.{base64.b64encode(dk).decode()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        salt_b64, dk_b64 = stored.split(".", 1)
        salt = base64.b64decode(salt_b64)
        expected = base64.b64decode(dk_b64)
        actual = _hash_password(password, salt)
        return hmac.compare_digest(actual, expected)  # constant-time
    except Exception:
        return False


@dataclass(frozen=True)
class AuthResult:
    ok: bool
    message: str


def login(username: str, password: str, user_password_hash_from_db: Optional[str]) -> AuthResult:
    """
    Example login flow. Replace `user_password_hash_from_db` lookup with real DB query.
    """
    if not isinstance(username, str) or not (3 <= len(username) <= 64):
        return AuthResult(False, "Invalid username")
    if user_password_hash_from_db is None:
        return AuthResult(False, "Invalid credentials")
    if not verify_password(password, user_password_hash_from_db):
        return AuthResult(False, "Invalid credentials")
    return AuthResult(True, "Login successful")
'''.lstrip()

        if any(k in lower for k in ["sql", "database", "query", "sqlite", "postgres", "mysql"]):
            return header + r'''
from __future__ import annotations

import sqlite3
from typing import Any, Dict, List, Sequence


def get_user_by_username(db_path: str, username: str) -> List[Dict[str, Any]]:
    """
    Secure example using parameterized queries (prevents SQL injection).
    Replace sqlite with your DB driver if needed (psycopg, mysqlclient, etc.).
    """
    if not isinstance(db_path, str) or not db_path:
        raise ValueError("db_path must be a non-empty string")
    if not isinstance(username, str) or not (1 <= len(username) <= 64):
        raise ValueError("username must be 1..64 chars")

    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row
    try:
        cur = con.cursor()
        cur.execute("SELECT id, username, created_at FROM users WHERE username = ?", (username,))
        rows = cur.fetchall()
        return [dict(r) for r in rows]
    finally:
        con.close()
'''.lstrip()

        if any(k in lower for k in ["upload", "file"]):
            return header + r'''
from __future__ import annotations

from pathlib import Path
from typing import BinaryIO, Iterable


ALLOWED_EXTS = {".png", ".jpg", ".jpeg", ".pdf", ".txt"}
MAX_BYTES = 5 * 1024 * 1024  # 5MB


def save_uploaded_file(stream: BinaryIO, original_filename: str, upload_dir: str) -> Path:
    """
    Secure file save:
    - extension allowlist
    - size limit
    - safe filename handling (no path traversal)
    """
    if not original_filename or not isinstance(original_filename, str):
        raise ValueError("original_filename is required")

    upload_path = Path(upload_dir).resolve()
    upload_path.mkdir(parents=True, exist_ok=True)

    name = Path(original_filename).name  # strips any directories
    ext = Path(name).suffix.lower()
    if ext not in ALLOWED_EXTS:
        raise ValueError(f"File type not allowed: {ext}")

    dest = (upload_path / name).resolve()
    if upload_path not in dest.parents and dest != upload_path:
        raise ValueError("Invalid file path")

    total = 0
    with open(dest, "wb") as f:
        while True:
            chunk = stream.read(64 * 1024)
            if not chunk:
                break
            total += len(chunk)
            if total > MAX_BYTES:
                raise ValueError("File too large")
            f.write(chunk)

    return dest
'''.lstrip()

        # Generic secure function skeleton
        return header + r'''
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional


@dataclass(frozen=True)
class Result:
    ok: bool
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None


def do_task(user_input: str) -> Result:
    """
    Secure starting point:
    - validate input
    - avoid hardcoded secrets
    - add error handling
    """
    if not isinstance(user_input, str) or not (10 <= len(user_input) <= 1000):
        return Result(ok=False, error="Invalid input")

    # TODO: implement actual logic based on your requirement
    return Result(ok=True, data={"message": "Implemented skeleton (offline mode)"})
'''.lstrip()
    
    def _extract_code_from_response(self, response: str) -> str:
        """Extract Python code from LLM response."""
        import re
        
        # Try to extract code blocks
        code_block_match = re.search(r'```(?:python)?\s*(.*?)```', response, re.DOTALL)
        if code_block_match:
            return code_block_match.group(1).strip()
        
        # If no code block, return the response as-is (might be plain code)
        return response.strip()
    
    def regenerate_code(self, user_input: str, feedback: str = "") -> str:
        """Regenerate code with feedback."""
        enhanced_input = f"{user_input}\n\nPrevious attempt had issues: {feedback}\nPlease generate improved code."
        return self.generate_code(enhanced_input)


# Example usage and testing
if __name__ == "__main__":
    compiler = CodeCompiler()
    test_input = "Create a login function with username and password"
    code = compiler.generate_code(test_input)
    print("Generated Code:")
    print(code)
