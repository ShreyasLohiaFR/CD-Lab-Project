"""
Configuration management module.
"""
import os
from typing import Dict, Any
from dotenv import load_dotenv

load_dotenv()


class Config:
    """Application configuration."""
    
    # API Configuration
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
    OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4-turbo-preview")
    OPENAI_TEMPERATURE = float(os.getenv("OPENAI_TEMPERATURE", "0.7"))
    OFFLINE_MODE = os.getenv("OFFLINE_MODE", "false").lower() in ("1", "true", "yes", "on")
    
    # Performance Settings
    MAX_ITERATIONS = int(os.getenv("MAX_ITERATIONS", "3"))
    TIMEOUT_SECONDS = int(os.getenv("TIMEOUT_SECONDS", "30"))
    CACHE_ENABLED = os.getenv("CACHE_ENABLED", "true").lower() == "true"
    CACHE_TTL = int(os.getenv("CACHE_TTL", "3600"))
    
    # Rate Limiting
    MAX_REQUESTS_PER_MINUTE = int(os.getenv("MAX_REQUESTS_PER_MINUTE", "10"))
    MAX_REQUESTS_PER_HOUR = int(os.getenv("MAX_REQUESTS_PER_HOUR", "100"))
    
    # Input Validation
    MAX_INPUT_LENGTH = int(os.getenv("MAX_INPUT_LENGTH", "1000"))
    MIN_INPUT_LENGTH = int(os.getenv("MIN_INPUT_LENGTH", "10"))
    
    # Security Settings
    ENABLE_RATE_LIMITING = os.getenv("ENABLE_RATE_LIMITING", "true").lower() == "true"
    ENABLE_INPUT_VALIDATION = os.getenv("ENABLE_INPUT_VALIDATION", "true").lower() == "true"
    
    # Logging
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
    LOG_FILE = os.getenv("LOG_FILE", "app.log")
    
    @classmethod
    def validate(cls) -> Dict[str, Any]:
        """Validate configuration and return status."""
        issues = []

        if not cls.OFFLINE_MODE and not cls.OPENAI_API_KEY:
            issues.append("OPENAI_API_KEY is not set (or set OFFLINE_MODE=true)")
        
        if cls.MAX_ITERATIONS < 1 or cls.MAX_ITERATIONS > 10:
            issues.append("MAX_ITERATIONS should be between 1 and 10")
        
        if cls.TIMEOUT_SECONDS < 5 or cls.TIMEOUT_SECONDS > 120:
            issues.append("TIMEOUT_SECONDS should be between 5 and 120")
        
        return {
            "valid": len(issues) == 0,
            "issues": issues
        }
    
    @classmethod
    def get_config_summary(cls) -> Dict[str, Any]:
        """Get configuration summary (without sensitive data)."""
        return {
            "offline_mode": cls.OFFLINE_MODE,
            "model": cls.OPENAI_MODEL,
            "temperature": cls.OPENAI_TEMPERATURE,
            "max_iterations": cls.MAX_ITERATIONS,
            "timeout": cls.TIMEOUT_SECONDS,
            "cache_enabled": cls.CACHE_ENABLED,
            "rate_limiting_enabled": cls.ENABLE_RATE_LIMITING,
            "input_validation_enabled": cls.ENABLE_INPUT_VALIDATION
        }
