"""
Basic vulnerability auditor using rule-based patterns and regex.
"""
import re
import ast
import logging
from typing import List, Dict, Any, Tuple
from .utils import logger


class BasicAuditor:
    """Rule-based vulnerability detector."""
    
    def __init__(self):
        """Initialize auditor with vulnerability patterns."""
        self.patterns = self._initialize_patterns()
        logger.info("BasicAuditor initialized")
    
    def _initialize_patterns(self) -> Dict[str, List[Dict[str, Any]]]:
        """Initialize regex patterns for vulnerability detection."""
        return {
            "sql_injection": [
                {
                    "pattern": r"execute\s*\(\s*['\"].*%[sd].*['\"]",
                    "severity": "high",
                    "description": "Potential SQL injection via string formatting in execute()"
                },
                {
                    "pattern": r"query\s*=\s*['\"].*\$\{.*\}.*['\"]",
                    "severity": "high",
                    "description": "Potential SQL injection via string interpolation"
                },
                {
                    "pattern": r"cursor\.execute\s*\(\s*['\"].*\+.*['\"]",
                    "severity": "high",
                    "description": "SQL injection risk: string concatenation in query"
                }
            ],
            "xss": [
                {
                    "pattern": r"\.innerHTML\s*=\s*.*request\.|\.innerHTML\s*=\s*.*input",
                    "severity": "high",
                    "description": "XSS vulnerability: unsanitized user input in innerHTML"
                },
                {
                    "pattern": r"render_template_string\s*\(.*request\.",
                    "severity": "high",
                    "description": "XSS vulnerability: unsanitized template rendering"
                }
            ],
            "weak_password_storage": [
                {
                    "pattern": r"password\s*=\s*['\"].*['\"]",
                    "severity": "high",
                    "description": "Hardcoded password detected"
                },
                {
                    "pattern": r"hashlib\.md5\s*\(",
                    "severity": "high",
                    "description": "Weak password hashing: MD5 is insecure"
                },
                {
                    "pattern": r"hashlib\.sha1\s*\(",
                    "severity": "medium",
                    "description": "Weak password hashing: SHA1 is deprecated"
                },
                {
                    "pattern": r"password.*=.*input\s*\(",
                    "severity": "medium",
                    "description": "Password stored without hashing"
                }
            ],
            "hardcoded_secrets": [
                {
                    "pattern": r"api_key\s*=\s*['\"][A-Za-z0-9]{20,}['\"]",
                    "severity": "high",
                    "description": "Hardcoded API key detected"
                },
                {
                    "pattern": r"secret\s*=\s*['\"][A-Za-z0-9]{10,}['\"]",
                    "severity": "high",
                    "description": "Hardcoded secret detected"
                },
                {
                    "pattern": r"token\s*=\s*['\"][A-Za-z0-9]{20,}['\"]",
                    "severity": "high",
                    "description": "Hardcoded token detected"
                }
            ],
            "missing_input_validation": [
                {
                    "pattern": r"def\s+\w+\(.*\):.*\n(?!.*validate|.*check|.*sanitize)",
                    "severity": "medium",
                    "description": "Function may lack input validation"
                }
            ],
            "command_injection": [
                {
                    "pattern": r"os\.system\s*\(\s*.*\+.*\)",
                    "severity": "high",
                    "description": "Command injection risk: os.system with string concatenation"
                },
                {
                    "pattern": r"subprocess\.call\s*\(\s*\[.*\+.*\]",
                    "severity": "high",
                    "description": "Command injection risk: subprocess with string concatenation"
                },
                {
                    "pattern": r"eval\s*\(",
                    "severity": "critical",
                    "description": "Critical: eval() usage allows code injection"
                },
                {
                    "pattern": r"exec\s*\(",
                    "severity": "critical",
                    "description": "Critical: exec() usage allows code injection"
                }
            ],
            "path_traversal": [
                {
                    "pattern": r"open\s*\(\s*.*\+.*request\.",
                    "severity": "high",
                    "description": "Path traversal risk: file path from user input"
                },
                {
                    "pattern": r"os\.path\.join\s*\(\s*.*request\.",
                    "severity": "medium",
                    "description": "Potential path traversal: user input in path join"
                }
            ],
            "csrf": [
                {
                    "pattern": r"@app\.route.*methods.*POST.*\n(?!.*csrf|.*token)",
                    "severity": "medium",
                    "description": "POST endpoint may lack CSRF protection"
                }
            ],
            "broken_authentication": [
                {
                    "pattern": r"if\s+password\s*==\s*['\"].*['\"]",
                    "severity": "high",
                    "description": "Broken authentication: plain text password comparison"
                },
                {
                    "pattern": r"session\[.user.].*=\s*.*request\.",
                    "severity": "medium",
                    "description": "Session management without proper validation"
                }
            ],
            "sensitive_data_exposure": [
                {
                    "pattern": r"print\s*\(\s*.*password|print\s*\(\s*.*secret|print\s*\(\s*.*token",
                    "severity": "high",
                    "description": "Sensitive data exposure: printing secrets"
                },
                {
                    "pattern": r"logging\.(info|debug|warning)\s*\(\s*.*password|.*secret|.*token",
                    "severity": "medium",
                    "description": "Sensitive data in logs"
                }
            ]
        }
    
    def audit(self, code: str) -> List[Dict[str, Any]]:
        """Audit code for vulnerabilities."""
        vulnerabilities = []
        lines = code.split('\n')
        
        for vuln_type, patterns in self.patterns.items():
            for pattern_info in patterns:
                pattern = pattern_info["pattern"]
                matches = self._find_matches(code, pattern, pattern_info, lines)
                vulnerabilities.extend(matches)
        
        # Remove duplicates and sort by severity
        vulnerabilities = self._deduplicate_vulnerabilities(vulnerabilities)
        vulnerabilities.sort(key=lambda x: self._severity_score(x["severity"]), reverse=True)
        
        logger.info(f"Audit completed: {len(vulnerabilities)} vulnerabilities found")
        return vulnerabilities
    
    def _find_matches(self, code: str, pattern: str, pattern_info: Dict[str, Any], 
                     lines: List[str]) -> List[Dict[str, Any]]:
        """Find pattern matches in code."""
        vulnerabilities = []
        
        try:
            # Try multiline matching for complex patterns
            matches = re.finditer(pattern, code, re.MULTILINE | re.IGNORECASE)
            for match in matches:
                line_num = code[:match.start()].count('\n') + 1
                if line_num <= len(lines):
                    vuln = {
                        "type": pattern_info.get("type", "unknown"),
                        "category": self._get_category_from_pattern(pattern),
                        "severity": pattern_info["severity"],
                        "line": line_num,
                        "description": pattern_info["description"],
                        "code_snippet": lines[line_num - 1].strip() if line_num <= len(lines) else "",
                        "fix_suggestion": self._get_fix_suggestion(pattern_info["description"])
                    }
                    vulnerabilities.append(vuln)
        except Exception as e:
            logger.warning(f"Error matching pattern {pattern}: {e}")
        
        return vulnerabilities
    
    def _get_category_from_pattern(self, pattern: str) -> str:
        """Extract vulnerability category from pattern."""
        if "sql" in pattern.lower():
            return "sql_injection"
        elif "xss" in pattern.lower() or "innerHTML" in pattern:
            return "xss"
        elif "password" in pattern.lower():
            return "weak_password_storage"
        elif "secret" in pattern.lower() or "api_key" in pattern.lower():
            return "hardcoded_secrets"
        elif "validate" in pattern.lower():
            return "missing_input_validation"
        elif "system" in pattern.lower() or "subprocess" in pattern.lower() or "eval" in pattern.lower():
            return "command_injection"
        elif "path" in pattern.lower() or "open" in pattern.lower():
            return "path_traversal"
        elif "csrf" in pattern.lower():
            return "csrf"
        elif "auth" in pattern.lower() or "session" in pattern.lower():
            return "broken_authentication"
        else:
            return "sensitive_data_exposure"
    
    def _get_fix_suggestion(self, description: str) -> str:
        """Generate fix suggestion based on vulnerability description."""
        suggestions = {
            "SQL injection": "Use parameterized queries with placeholders (?, %s, :name)",
            "XSS": "Sanitize and escape user input before rendering",
            "Weak password hashing": "Use bcrypt or argon2 for password hashing",
            "Hardcoded": "Move secrets to environment variables or secure vault",
            "Input validation": "Add input validation and sanitization",
            "Command injection": "Use subprocess with list arguments, avoid shell=True",
            "Path traversal": "Validate and sanitize file paths, use os.path.join safely",
            "CSRF": "Implement CSRF tokens for state-changing operations",
            "Authentication": "Use secure password comparison (bcrypt.checkpw)",
            "Sensitive data": "Never log or print sensitive information"
        }
        
        for key, suggestion in suggestions.items():
            if key.lower() in description.lower():
                return suggestion
        
        return "Review security best practices and implement proper safeguards"
    
    def _severity_score(self, severity: str) -> int:
        """Convert severity to numeric score for sorting."""
        scores = {"critical": 4, "high": 3, "medium": 2, "low": 1}
        return scores.get(severity.lower(), 0)
    
    def _deduplicate_vulnerabilities(self, vulnerabilities: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Remove duplicate vulnerabilities."""
        seen = set()
        unique = []
        for vuln in vulnerabilities:
            key = (vuln["line"], vuln["category"], vuln["type"])
            if key not in seen:
                seen.add(key)
                unique.append(vuln)
        return unique
    
    def is_secure(self, code: str, max_vulnerabilities: int = 0) -> Tuple[bool, List[Dict[str, Any]]]:
        """Check if code is secure (no high/critical vulnerabilities)."""
        vulnerabilities = self.audit(code)
        high_severity = [v for v in vulnerabilities if v["severity"] in ["high", "critical"]]
        
        is_secure = len(high_severity) <= max_vulnerabilities
        return is_secure, vulnerabilities


# Example usage
if __name__ == "__main__":
    auditor = BasicAuditor()
    test_code = """
    def login(username, password):
        query = "SELECT * FROM users WHERE username = '" + username + "'"
        cursor.execute(query)
        return cursor.fetchone()
    """
    
    vulnerabilities = auditor.audit(test_code)
    print(f"Found {len(vulnerabilities)} vulnerabilities:")
    for vuln in vulnerabilities:
        print(f"  - {vuln['severity'].upper()}: {vuln['description']} (Line {vuln['line']})")
