"""
System prompts and templates for code generation and security enforcement.
"""
from typing import List, Dict


# Security-enforced code generation prompt
SECURITY_CODE_GENERATION_PROMPT = """You are a security-aware code generator. Generate secure, production-ready Python code based on the user's natural language description.

REQUIREMENTS:
1. Follow OWASP Top 10 security guidelines
2. Never include hardcoded secrets, passwords, or API keys
3. Always validate and sanitize user inputs
4. Use parameterized queries for database operations
5. Implement proper authentication and authorization
6. Use secure password hashing (bcrypt, argon2)
7. Prevent SQL injection, XSS, CSRF attacks
8. Include proper error handling
9. Add input validation and sanitization
10. Use secure session management

VULNERABILITY TYPES TO AVOID:
- SQL Injection
- XSS (Cross-Site Scripting)
- Weak Password Storage
- Hardcoded Secrets
- Missing Input Validation
- Command Injection
- Path Traversal
- CSRF (Cross-Site Request Forgery)
- Broken Authentication
- Sensitive Data Exposure

Generate clean, well-documented, secure code that follows Python best practices.

User Request: {user_input}

Generate secure Python code:"""


# Intent extraction prompt
INTENT_EXTRACTION_PROMPT = """Extract the programming intent from the following natural language description.

Identify:
1. Main functionality requested
2. Required components/modules
3. Security requirements
4. Input/output specifications
5. Error handling needs

User Description: {user_input}

Provide a structured intent analysis in JSON format:
{{
    "functionality": "description",
    "components": ["list", "of", "components"],
    "security_requirements": ["list", "of", "requirements"],
    "inputs": ["list", "of", "inputs"],
    "outputs": ["list", "of", "outputs"]
}}"""


# Code fixing prompt
CODE_FIXING_PROMPT = """The following code has security vulnerabilities. Fix all identified issues and return the secure version.

Vulnerabilities found:
{vulnerabilities}

Original Code:
{code}

Generate the fixed, secure version of the code. Ensure:
1. All vulnerabilities are addressed
2. Code functionality is preserved
3. Security best practices are followed
4. Code remains readable and maintainable

Fixed Code:"""


# Vulnerability detection prompt
VULNERABILITY_DETECTION_PROMPT = """Analyze the following Python code for security vulnerabilities.

Check for:
1. SQL Injection vulnerabilities
2. XSS (Cross-Site Scripting) vulnerabilities
3. Weak password storage
4. Hardcoded secrets or credentials
5. Missing input validation
6. Command injection vulnerabilities
7. Path traversal vulnerabilities
8. CSRF vulnerabilities
9. Broken authentication mechanisms
10. Sensitive data exposure

Code to analyze:
{code}

Provide a JSON response with detected vulnerabilities:
{{
    "vulnerabilities": [
        {{
            "type": "vulnerability_type",
            "severity": "high|medium|low",
            "line": line_number,
            "description": "detailed description",
            "fix_suggestion": "how to fix"
        }}
    ],
    "security_score": 0-100
}}"""


# Agent decision prompt
AGENT_DECISION_PROMPT = """You are an autonomous security agent. Analyze the code generation and audit results to decide the next action.

Current Status:
- Code Generated: {code_generated}
- Vulnerabilities Found: {vulnerability_count}
- Iteration: {iteration}/{max_iterations}

Available Actions:
1. ACCEPT: Code is secure, return to user
2. FIX: Fix vulnerabilities and re-audit
3. REGENERATE: Generate new code from scratch

Decision:"""


def get_security_constraints() -> List[str]:
    """Get list of security constraints to enforce."""
    return [
        "No hardcoded passwords or secrets",
        "Input validation required",
        "Parameterized database queries only",
        "Secure password hashing (bcrypt/argon2)",
        "XSS prevention (output encoding)",
        "CSRF protection",
        "Secure session management",
        "Error handling without information leakage",
        "Path traversal prevention",
        "Command injection prevention"
    ]


def get_owasp_top10_guidelines() -> Dict[str, str]:
    """Get OWASP Top 10 security guidelines."""
    return {
        "A01:2021-Broken Access Control": "Implement proper authorization checks",
        "A02:2021-Cryptographic Failures": "Use strong encryption and hashing",
        "A03:2021-Injection": "Use parameterized queries and input validation",
        "A04:2021-Insecure Design": "Follow secure design principles",
        "A05:2021-Security Misconfiguration": "Use secure default configurations",
        "A06:2021-Vulnerable Components": "Keep dependencies updated",
        "A07:2021-Authentication Failures": "Implement strong authentication",
        "A08:2021-Software and Data Integrity": "Verify data integrity",
        "A09:2021-Security Logging Failures": "Implement comprehensive logging",
        "A10:2021-Server-Side Request Forgery": "Validate and sanitize URLs"
    }
