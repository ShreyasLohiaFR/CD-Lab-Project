"""
Utility functions for the secure code compiler.
"""
import os
import json
import logging
from typing import Dict, Any, Optional
from datetime import datetime
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def get_env_var(key: str, default: Optional[str] = None) -> str:
    """Get environment variable with optional default."""
    value = os.getenv(key, default)
    if value is None:
        raise ValueError(f"Environment variable {key} is not set")
    return value


def save_code_to_file(code: str, filename: str = None) -> str:
    """Save generated code to a file."""
    if filename is None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"generated_code_{timestamp}.py"
    
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(code)
    
    logger.info(f"Code saved to {filename}")
    return filename


def load_json_file(filepath: str) -> Dict[str, Any]:
    """Load JSON file."""
    with open(filepath, 'r', encoding='utf-8') as f:
        return json.load(f)


def save_json_file(data: Dict[str, Any], filepath: str) -> None:
    """Save data to JSON file."""
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def format_audit_report(vulnerabilities: list, code: str) -> Dict[str, Any]:
    """Format security audit report."""
    return {
        "timestamp": datetime.now().isoformat(),
        "code_length": len(code),
        "vulnerability_count": len(vulnerabilities),
        "vulnerabilities": vulnerabilities,
        "security_score": max(0, 100 - len(vulnerabilities) * 10)
    }


def calculate_metrics(start_time: datetime, end_time: datetime, 
                     api_calls: int = 0) -> Dict[str, Any]:
    """Calculate performance metrics."""
    duration = (end_time - start_time).total_seconds()
    return {
        "response_time": duration,
        "api_calls": api_calls,
        "timestamp": end_time.isoformat()
    }
