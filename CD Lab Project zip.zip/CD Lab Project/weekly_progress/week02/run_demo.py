from pathlib import Path


def main() -> None:
    print("WEEK 02 DEMO: Literature Survey & Gap")
    print("-" * 60)
    print("This week is research-focused (no implementation required).")
    print("Deliverable:")
    print("- deliverables/week02/LITERATURE_SURVEY.md")
    print("")
    print("Key takeaway:")
    print("- ChatGPT/Copilot: functional code, often insecure")
    print("- Gap: need security-aware generation + automated audit + autonomous fixing")

    root = Path(__file__).resolve().parents[2]
    p = root / "deliverables" / "week02" / "LITERATURE_SURVEY.md"
    print(f"OK exists: {p.exists()} -> {p}")


if __name__ == "__main__":
    main()