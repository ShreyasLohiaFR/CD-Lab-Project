# Week 02 — What to show

## Show these deliverables
- `deliverables/week02/LITERATURE_SURVEY.md`

## What to say
- Existing tools generate code but do not guarantee security.
- Research gap: no end-to-end NL→code system with automated audit + autonomous fixing.

## Demo
Run:

```powershell
python .\weekly_progress\week02\run_demo.py
```