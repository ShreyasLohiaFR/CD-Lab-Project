# Week 01 — What to show

## Show these deliverables
- `deliverables/week01/PROBLEM_DEFINITION.md`
- `deliverables/week01/COMPILER_PHASES_DIAGRAM.md`

## What to say
- Problem: AI code generators produce insecure code.
- Goal: Natural language → secure Python code.
- 4 phases: NLP parsing → generation → auditing → agentic fixing.

## Demo
Run:

```powershell
python .\weekly_progress\week01\run_demo.py
```