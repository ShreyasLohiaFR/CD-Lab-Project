from pathlib import Path


def main() -> None:
    print("WEEK 01 DEMO: Problem Definition & Context")
    print("-" * 60)
    print("This week is documentation-focused (no implementation required).")
    print("Deliverables:")
    print("- deliverables/week01/PROBLEM_DEFINITION.md")
    print("- deliverables/week01/COMPILER_PHASES_DIAGRAM.md")
    print("")
    print("Key concept: 4-phase secure compiler")
    print("1) NLP Parsing -> intent extraction")
    print("2) Code Generation -> LLM with security constraints")
    print("3) Security Auditing -> regex + AST + dataflow")
    print("4) Agentic Fixing -> iterate until secure")

    root = Path(__file__).resolve().parents[2]
    for p in [
        root / "deliverables" / "week01" / "PROBLEM_DEFINITION.md",
        root / "deliverables" / "week01" / "COMPILER_PHASES_DIAGRAM.md",
    ]:
        print(f"OK exists: {p.exists()} -> {p}")


if __name__ == "__main__":
    main()