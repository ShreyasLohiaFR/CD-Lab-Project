# End-to-End Natural Language to Secure Code Compiler with Agentic AI

**Student Name:** Shreyas Prakash Lohia  
**Roll Number:** 24CSB0B70  
**Course:** Compiler Design / Advanced Systems Programming  
**Semester:** 4  
**Date of Submission:** January 6, 2026

## Project Overview

This project implements an intelligent compiler that converts natural language descriptions into secure, production-ready code using Agentic AI. The system combines NLP parsing, LLM-based code generation, and automated security auditing to produce vulnerability-free code.

## Key Features

- **Natural Language Processing**: Accepts English descriptions and extract programming intent
- **AI-Powered Code Generation**: Uses OpenAI API with LangChain for intelligent code generation
- **Security Auditing**: Detects 10+ vulnerability types including SQL Injection, XSS, weak password storage
- **Agentic AI Loop**: Autonomous decision-making with function calling to fix vulnerabilities automatically
- **AST Analysis**: Advanced code analysis using Abstract Syntax Trees
- **Data Flow Analysis**: Tracks tainted variables and data flow vulnerabilities
- **Performance Optimized**: Response time <10s, cost <$0.05/request
- **Input Validation**: Comprehensive input validation and sanitization
- **Rate Limiting**: Built-in rate limiting to prevent API abuse
- **Code Formatting**: Automatic code formatting and quality enhancement
- **Code Quality Metrics**: Real-time code quality analysis and suggestions
- **Advanced Logging**: Structured logging with file and console handlers
- **Configuration Management**: Centralized, environment-based configuration

## Project Structure

```
secure-code-compiler/
├── src/                          # Source code modules
│   ├── frontend.py              # Streamlit UI
│   ├── compiler.py              # Code generator
│   ├── auditor_basic.py         # Basic vulnerability auditor
│   ├── ast_analyzer.py          # AST analysis
│   ├── dataflow_analyzer.py     # Data flow analysis
│   ├── agent.py                 # Agentic AI implementation
│   ├── agent_orchestrator.py    # Agent loop control
│   ├── optimizer.py             # Performance optimization
│   ├── security_enforcer.py     # Security enforcement
│   ├── explainability.py        # Explanations module
│   ├── visualizer.py            # Visualizations
│   ├── prompts.py               # System prompts and templates
│   ├── input_validator.py       # Input validation & sanitization
│   ├── rate_limiter.py          # Rate limiting
│   ├── code_formatter.py        # Code formatting & quality
│   ├── config.py                # Configuration management
│   ├── logger_config.py         # Advanced logging
│   └── utils.py                 # Utility functions
├── tests/                        # Test suite
│   ├── test_suite.py            # Comprehensive test suite (50+ cases)
│   ├── test_parser.py           # Parser tests
│   ├── test_compiler.py         # Compiler tests
│   ├── test_auditor.py          # Auditor tests
│   └── test_agent.py            # Agent tests
├── deliverables/                 # Weekly deliverables
│   ├── week01/                  # Week 1 deliverables
│   ├── week02/                  # Week 2 deliverables
│   ├── ...                      # Weeks 3-14
│   └── week14/                  # Week 14 deliverables
├── docs/                         # Documentation
│   ├── DOCUMENTATION.md         # Technical documentation
│   ├── ARCHITECTURE.md          # System architecture
│   ├── API_REFERENCE.md         # API reference
│   └── USER_GUIDE.md             # User guide
├── demo/                         # Demo materials
│   ├── demo_video_script.md     # Demo video script
│   └── presentation/            # Presentation slides
├── requirements.txt             # Python dependencies
├── .env.example                 # Environment variables template
└── main.py                      # Main entry point

```

## Installation

### Prerequisites

- Python 3.8 or higher
- OpenAI API key
- pip package manager

### Setup Steps

1. **Clone or download the project**
   ```bash
   cd "c:\Users\HP\Desktop\CD Lab Project"
   ```

2. **Create a virtual environment (recommended)**
   ```bash
   python -m venv venv
   venv\Scripts\activate  # On Windows
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Set up environment variables**
   ```bash
   copy .env.example .env
   # Edit .env and add your OpenAI API key:
   # OPENAI_API_KEY=your_api_key_here
   ```

5. **Run the application**
   ```bash
   streamlit run src/frontend.py
   ```

   Or use the main entry point:
   ```bash
   python main.py
   ```

## Usage

1. **Start the application**: Run `streamlit run src/frontend.py`
2. **Enter natural language request**: Type your code requirement in English (e.g., "Create a login form with password validation")
3. **Click "Compile Secure Code"**: The system will:
   - Parse your intent
   - Generate secure code
   - Audit for vulnerabilities
   - Automatically fix any issues found
   - Return the final secure code
4. **Review output**: View the generated code and security audit report
5. **Download**: Save the generated code if needed

## Example Inputs

- "Create a login form with username and password fields"
- "Build a function to query user data from database"
- "Generate code for file upload with validation"
- "Create an API endpoint for user registration"
- "Build a function to hash passwords securely"

## Vulnerability Detection

The system detects and fixes:
1. SQL Injection
2. XSS (Cross-Site Scripting)
3. Weak Password Storage
4. Hardcoded Secrets
5. Missing Input Validation
6. Command Injection
7. Path Traversal
8. CSRF (Cross-Site Request Forgery)
9. Broken Authentication
10. Sensitive Data Exposure

## Testing

Run the comprehensive test suite:

```bash
python -m pytest tests/ -v --cov=src --cov-report=html
```

This will:
- Run 50+ test cases
- Generate code coverage report (target: >80%)
- Show detailed test results

## Performance Metrics

- **Response Time**: <10 seconds
- **API Cost**: <$0.05 per request
- **Vulnerability Detection**: 95%+ accuracy
- **False Positive Rate**: <5%
- **Test Coverage**: >80%

## Technology Stack

- **Frontend**: Streamlit
- **NLP/LLM**: OpenAI API, LangChain
- **Code Analysis**: AST (Python's `ast` module)
- **Testing**: pytest, coverage
- **Visualization**: matplotlib, plotly
- **Code Quality**: black, flake8, mypy
- **Security**: Input validation, rate limiting, pattern detection

## Project Phases

- **Phase 1** (Week 1-2): Problem Understanding & Foundations
- **Phase 2** (Week 3-4): Requirements & Design
- **Phase 3** (Week 5-8): Core Development
- **Phase 4** (Week 9-10): Intelligence, Optimization & Security
- **Phase 5** (Week 11-12): Testing & Validation
- **Phase 6** (Week 13): Explainability & Documentation
- **Phase 7** (Week 14): Final Refinement & Submission

## Deliverables

All weekly deliverables are organized in the `deliverables/` directory, with each week having its own subdirectory containing:
- Documentation
- Diagrams
- Test results
- Analysis reports

## Contributing

This is an academic project. For questions or issues, please refer to the documentation in the `docs/` directory.

## License

Academic project for Compiler Design Lab, Semester 4.

## Contact

**Student:** Shreyas Prakash Lohia  
**Roll Number:** 24CSB0B70
