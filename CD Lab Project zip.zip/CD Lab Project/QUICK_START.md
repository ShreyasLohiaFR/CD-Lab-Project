# Quick Start Guide

## Setup (5 minutes)

1. **Install Python 3.8+** (if not already installed)

2. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Set Up API Key**
   - Copy `.env.example` to `.env`
   - Add your OpenAI API key:
     ```
     OPENAI_API_KEY=your_api_key_here
     ```

4. **Run the Application**
   ```bash
   # Option 1: Web UI (Recommended)
   streamlit run src/frontend.py
   
   # Option 2: Command Line
   python main.py --input "Create a login function"
   
   # Option 3: Web UI via main.py
   python main.py --ui
   ```

## First Test

1. Open the web interface (http://localhost:8501)
2. Enter: "Create a secure login function with password hashing"
3. Click "Compile Secure Code"
4. Review the generated code and security report

## Project Structure Overview

```
CD Lab Project/
├── src/                    # All source code modules (12 files)
│   ├── frontend.py         # Streamlit UI
│   ├── compiler.py         # Code generation
│   ├── auditor_basic.py    # Vulnerability detection
│   ├── agent.py            # Agentic AI
│   └── ...                 # Other modules
├── tests/                  # Test suite (50+ tests)
├── deliverables/           # Weekly deliverables (Week 1-14)
├── docs/                   # Technical documentation
├── demo/                   # Demo materials
└── README.md              # Main documentation
```

## Key Features to Test

1. **Code Generation**: Enter natural language, get secure code
2. **Vulnerability Detection**: System automatically finds security issues
3. **Automatic Fixing**: Agent fixes vulnerabilities autonomously
4. **Security Report**: View detailed security analysis
5. **Visualizations**: See vulnerability heatmaps and metrics

## Troubleshooting

**Issue**: "OPENAI_API_KEY not found"
- **Solution**: Create `.env` file with your API key

**Issue**: "Module not found"
- **Solution**: Run `pip install -r requirements.txt`

**Issue**: "Streamlit not found"
- **Solution**: Install with `pip install streamlit`

## Next Steps

1. Read `README.md` for detailed documentation
2. Review `deliverables/` for weekly progress
3. Check `docs/` for technical details
4. Run tests: `pytest tests/ -v`

## Support

For issues or questions, refer to:
- `README.md` - Main documentation
- `docs/DOCUMENTATION.md` - Technical details
- `deliverables/week14/FINAL_SUBMISSION.md` - Project summary
