"""
OFFLINE_MODE TEMPLATE OUTPUT

Original request:
Create a secure login function with password hashing

Note:
- This output was generated WITHOUT OpenAI (no API calls).
- It is a secure starting point; customize for your app/database/framework.
"""
from __future__ import annotations

import base64
import hmac
import os
from dataclasses import dataclass
from hashlib import pbkdf2_hmac
from typing import Optional


PBKDF2_ITERATIONS = 210_000
SALT_BYTES = 16
DKLEN = 32


def _hash_password(password: str, salt: bytes) -> bytes:
    if not isinstance(password, str) or len(password) < 8:
        raise ValueError("Password must be a string with length >= 8")
    return pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS, dklen=DKLEN)


def hash_password_for_storage(password: str) -> str:
    """
    Returns a storage string: base64(salt) + "." + base64(derived_key)
    Store this value in DB; never store plaintext passwords.
    """
    salt = os.urandom(SALT_BYTES)
    dk = _hash_password(password, salt)
    return f"{base64.b64encode(salt).decode()}.{base64.b64encode(dk).decode()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        salt_b64, dk_b64 = stored.split(".", 1)
        salt = base64.b64decode(salt_b64)
        expected = base64.b64decode(dk_b64)
        actual = _hash_password(password, salt)
        return hmac.compare_digest(actual, expected)  # constant-time
    except Exception:
        return False


@dataclass(frozen=True)
class AuthResult:
    ok: bool
    message: str


def login(username: str, password: str, user_password_hash_from_db: Optional[str]) -> AuthResult:
    """
    Example login flow. Replace `user_password_hash_from_db` lookup with real DB query.
    """
    if not isinstance(username, str) or not (3 <= len(username) <= 64):
        return AuthResult(False, "Invalid username")
    if user_password_hash_from_db is None:
        return AuthResult(False, "Invalid credentials")
    if not verify_password(password, user_password_hash_from_db):
        return AuthResult(False, "Invalid credentials")
    return AuthResult(True, "Login successful")
