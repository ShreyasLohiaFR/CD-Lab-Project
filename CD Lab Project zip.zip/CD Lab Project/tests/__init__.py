"""
Test package for Secure Code Compiler.
"""
