"""
Main entry point for the Secure Code Compiler.
"""
import sys
import os
import argparse
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))

from src.agent_orchestrator import AgentOrchestrator
from src.explainability import ExplainabilityModule
from src.utils import logger, save_code_to_file


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description="Secure Code Compiler - Natural Language to Secure Code")
    parser.add_argument(
        "--input",
        "-i",
        type=str,
        help="Natural language code requirement"
    )
    parser.add_argument(
        "--output",
        "-o",
        type=str,
        help="Output file path for generated code"
    )
    parser.add_argument(
        "--iterations",
        type=int,
        default=3,
        help="Maximum agent iterations (default: 3)"
    )
    parser.add_argument(
        "--ui",
        action="store_true",
        help="Launch Streamlit UI"
    )
    
    args = parser.parse_args()
    
    if args.ui:
        # Launch Streamlit UI
        import subprocess
        frontend_path = Path(__file__).parent / "src" / "frontend.py"
        subprocess.run(["streamlit", "run", str(frontend_path)])
    elif args.input:
        # CLI mode
        print("=" * 60)
        print("Secure Code Compiler")
        print("=" * 60)
        print(f"\nInput: {args.input}\n")
        
        orchestrator = AgentOrchestrator(max_iterations=args.iterations)
        explainer = ExplainabilityModule()
        
        print("Generating secure code...")
        result = orchestrator.orchestrate(args.input)
        
        if result.get("status") == "success":
            print("\n" + "=" * 60)
            print("GENERATION COMPLETE")
            print("=" * 60)
            
            # Display code
            print("\nGenerated Code:")
            print("-" * 60)
            print(result.get("code", ""))
            print("-" * 60)
            
            # Display metrics
            print(f"\nSecurity Score: {result.get('security_score', 0)}/100")
            print(f"Vulnerabilities: {len(result.get('vulnerabilities', []))}")
            print(f"Iterations: {result.get('iterations', 0)}")
            
            if result.get('metrics'):
                print(f"Response Time: {result['metrics'].get('response_time', 0):.2f}s")
            
            # Display vulnerabilities
            vulnerabilities = result.get('vulnerabilities', [])
            if vulnerabilities:
                print(f"\n[!] Detected {len(vulnerabilities)} vulnerabilities:")
                for i, vuln in enumerate(vulnerabilities[:5], 1):
                    print(f"  {i}. [{vuln.get('severity', 'unknown').upper()}] {vuln.get('description', 'N/A')}")
            else:
                print("\n[OK] No vulnerabilities detected!")
            
            # Save to file
            if args.output:
                output_path = args.output
            else:
                output_path = save_code_to_file(result.get("code", ""))
            
            print(f"\nCode saved to: {output_path}")
            
            # Display explanation
            print("\n" + "=" * 60)
            print("EXPLANATION")
            print("=" * 60)
            explanation = explainer.generate_full_explanation(result)
            print(explanation)
        else:
            print(f"\n[ERROR] {result.get('error', 'Unknown error')}")
            sys.exit(1)
    else:
        parser.print_help()
        print("\nTip: Use --ui to launch the web interface")
        print("     Or use --input 'your requirement' for CLI mode")


if __name__ == "__main__":
    main()
