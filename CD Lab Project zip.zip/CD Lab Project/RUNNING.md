## How to run this project (Windows 10/11 + PowerShell)

This project is a Python app with a Streamlit UI.

### 1) Open PowerShell in the project folder

```powershell
cd "c:\Users\HP\Desktop\All NITW Files\CD Lab Project"
```

### 2) (Recommended) Use the existing virtual environment

If you already have `.venv/` in this folder, activate it.

If PowerShell blocks activation, run the bypass **for this window only**.

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
python --version
```

If you **do not** have `.venv/`, create it:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

### 3) Install requirements

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 4) Configure environment variables (.env)

Copy the example file:

```powershell
Copy-Item .\.env.example .\.env
```

Now open `.env` and choose ONE of the following:

#### Option A (No OpenAI budget): run offline templates (recommended for demo)

Set:

- `OFFLINE_MODE=true`

You can leave `OPENAI_API_KEY` empty or as a placeholder.

#### Option B (Use OpenAI): run with an API key

Set:

- `OFFLINE_MODE=false`
- `OPENAI_API_KEY=...your key...`

If the key has **no credits/budget**, calls will fail; use **Option A** instead.

Tip: keep `OFFLINE_FALLBACK=true` (default) to automatically fall back to offline templates if OpenAI calls fail (quota/network).

### 5) Run the app

#### Run Streamlit UI (recommended)

```powershell
streamlit run .\src\frontend.py
```

Then open the URL shown in the terminal (usually `http://localhost:8501`).

#### Run CLI mode

```powershell
python .\main.py --input "Create a secure login function with password hashing"
```

#### Launch UI via main.py

```powershell
python .\main.py --ui
```

### 6) What works in OFFLINE_MODE

- The app runs fully (UI + CLI)
- It generates **secure template code** without any OpenAI calls
- The rule-based security auditor still runs on the generated code

### Troubleshooting

- **`streamlit` not recognized**: make sure the venv is activated, then re-run `pip install -r requirements.txt`.
- **Activation error**: run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` and activate again.
- **Port already in use**: stop other Streamlit runs, or use `streamlit run .\src\frontend.py --server.port 8502`

